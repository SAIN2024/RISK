using RISK.Core.Config;

namespace RISK.UI;

public sealed class VplcSetupForm : Form
{
    private readonly TextBox _siemens = new();
    private readonly TextBox _plcnext = new();
    private readonly TextBox _codesys = new();
    private readonly CheckBox _offline = new() { Text = "Use bundled offline vPLC simulators when paths are not available", Checked = true, AutoSize = true };
    public VplcConfiguration SelectedConfiguration { get; private set; } = VplcConfiguration.CreateDefault();

    public VplcSetupForm()
    {
        Text = "RISK - vPLC Location Setup";
        Width = 820; Height = 420; StartPosition = FormStartPosition.CenterScreen;
        var title = new Label { Text = "Select vPLC locations", Font = new Font(FontFamily.GenericSansSerif, 16, FontStyle.Bold), Left = 20, Top = 18, Width = 500 };
        var hint = new Label { Text = "RISK begins by recording the local paths of the vPLC environments. No external PLC is contacted by this artifact; empty entries fall back to offline simulators.", Left=20, Top=55, Width=740, Height=45 };
        Controls.Add(title); Controls.Add(hint);
        AddRow("SIMATIC S7-1500V path", _siemens, 112);
        AddRow("PLCnext Control / vPLCnext path", _plcnext, 162);
        AddRow("CODESYS Control SL path", _codesys, 212);
        _offline.Left=205; _offline.Top=262; Controls.Add(_offline);
        var demo = new Button { Text="Use sample simulator paths", Left=205, Top=304, Width=190, Height=36 };
        demo.Click += (_,__) => { _siemens.Text=@".\Simulators\S7_1500V"; _plcnext.Text=@".\Simulators\PLCnext"; _codesys.Text=@".\Simulators\CODESYS_SL"; };
        var ok = new Button { Text="Continue", Left=590, Top=304, Width=120, Height=36, DialogResult=DialogResult.OK };
        ok.Click += (_,__) => { SelectedConfiguration = new VplcConfiguration(_siemens.Text.Trim(), _plcnext.Text.Trim(), _codesys.Text.Trim(), _offline.Checked); };
        var cancel = new Button { Text="Cancel", Left=460, Top=304, Width=110, Height=36, DialogResult=DialogResult.Cancel };
        Controls.Add(demo); Controls.Add(ok); Controls.Add(cancel); AcceptButton=ok; CancelButton=cancel;
    }
    private void AddRow(string label, TextBox box, int top)
    {
        Controls.Add(new Label{Text=label, Left=20, Top=top+6, Width=175});
        box.Left=205; box.Top=top; box.Width=505; box.Anchor=AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Top; Controls.Add(box);
        var browse = new Button{Text="Browse", Left=720, Top=top-1, Width=70};
        browse.Click += (_,__) => { using var dlg = new FolderBrowserDialog(); if (dlg.ShowDialog()==DialogResult.OK) box.Text=dlg.SelectedPath; };
        Controls.Add(browse);
    }
}
