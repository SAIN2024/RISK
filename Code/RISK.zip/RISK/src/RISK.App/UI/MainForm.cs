using RISK.Core.Config;
using RISK.Core.Evaluation;
using RISK.Core.Reporting;

namespace RISK.UI;

public sealed class MainForm : Form
{
    private readonly RichTextBox _log = new() { Dock = DockStyle.Fill, Font = new Font("Consolas", 10) };
    private readonly PipelineRunner _runner;
    private readonly ListView _results = new() { View = View.Details, Dock = DockStyle.Bottom, Height = 210, FullRowSelect=true };
    public MainForm(VplcConfiguration cfg)
    {
        Text = "RISK - Model-Guided TLTR Discovery Artifact"; Width = 1180; Height = 780; StartPosition = FormStartPosition.CenterScreen;
        _runner = new PipelineRunner(cfg, Append);
        var bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height=50, Padding = new Padding(8) };
        var run = new Button { Text="Run end-to-end pipeline", Width=180, Height=32 }; run.Click += async (_,__) => await RunPipeline();
        var export = new Button { Text="Export report", Width=120, Height=32 }; export.Click += (_,__) => Export();
        var clear = new Button { Text="Clear", Width=80, Height=32 }; clear.Click += (_,__) => { _log.Clear(); _results.Items.Clear(); };
        bar.Controls.Add(run); bar.Controls.Add(export); bar.Controls.Add(clear);
        _results.Columns.Add("Testbed", 120); _results.Columns.Add("Script", 180); _results.Columns.Add("t_d", 70); _results.Columns.Add("t_c", 70); _results.Columns.Add("Classification", 150); _results.Columns.Add("Reason", 520);
        Controls.Add(_log); Controls.Add(_results); Controls.Add(bar);
        Append("RISK started. vPLC paths were recorded; offline simulator mode is available for artifact review.");
    }
    private async Task RunPipeline()
    {
        _results.Items.Clear();
        var outcomes = await Task.Run(() => _runner.RunAll());
        foreach (var o in outcomes)
        {
            var item = new ListViewItem(o.Testbed);
            item.SubItems.Add(o.ScriptId); item.SubItems.Add(o.RecoveryStart.ToString("0.00")); item.SubItems.Add(o.RecoveryComplete.ToString("0.00"));
            item.SubItems.Add(o.Classification.ToString()); item.SubItems.Add(o.Explanation); _results.Items.Add(item);
        }
    }
    private void Export()
    {
        var dir = Path.Combine(AppContext.BaseDirectory, "output"); Directory.CreateDirectory(dir);
        var p = Path.Combine(dir, "risk-artifact-report.md");
        File.WriteAllText(p, MarkdownReport.FromList(_runner.LastOutcomes));
        MessageBox.Show("Report written to " + p, "RISK");
    }
    private void Append(string s)
    {
        if (InvokeRequired) { BeginInvoke(new Action<string>(Append), s); return; }
        _log.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + s + Environment.NewLine);
    }
}
