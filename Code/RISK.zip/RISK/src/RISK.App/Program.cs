using RISK.UI;

namespace RISK;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        using var setup = new VplcSetupForm();
        if (setup.ShowDialog() == DialogResult.OK)
        {
            Application.Run(new MainForm(setup.SelectedConfiguration));
        }
    }
}
