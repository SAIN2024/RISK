# Mapping to Paper Sections

* Section 7.1: `Core/Constraints`, `Core/Mcm`
* Section 7.2: `Core/TraceAnalysis`
* Section 7.3: `Core/AttackGeneration`, `Core/Vplc`
* Section 7.4: `Core/Recovery`
* Section 8: `Core/Evaluation`, sample traces and testbed profiles
