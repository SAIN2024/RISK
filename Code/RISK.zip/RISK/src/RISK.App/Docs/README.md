# RISK Artifact

This is a C# WinForms artifact for the RISK pipeline. It is intentionally offline: vPLC paths are collected at startup for configuration/audit purposes, but the bundled execution runtime uses local simulators so reviewers can run the workflow without a live plant.

Run with Visual Studio 2022 or `dotnet run --project src/RISK.App/RISK.App.csproj` on Windows with .NET 8 desktop workload.

Pipeline: PLC/policy parsing -> MCM construction -> trace partitioning -> slack and recovery pattern extraction -> candidate script generation -> local vPLC-style execution -> recovery infeasible/unsafe classification.
