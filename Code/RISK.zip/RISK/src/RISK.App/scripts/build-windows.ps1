dotnet build .\RISK.sln -c Release
