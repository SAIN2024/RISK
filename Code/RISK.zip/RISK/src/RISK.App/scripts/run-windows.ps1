dotnet run --project .\src\RISK.App\RISK.App.csproj
