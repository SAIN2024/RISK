using RISK.Core.Domain;

namespace RISK.Core.AttackGeneration;

public sealed class AttackValidator
{
    public bool Validate(AttackScript script, McmGraph mcm, out string reason)
    {
        foreach (var st in script.Stages)
        foreach (var kv in st.Assignments)
        {
            if (double.IsNaN(kv.Value) || double.IsInfinity(kv.Value)) { reason=$"invalid numeric assignment in {st.Name}"; return false; }
            if (kv.Value < -0.05 || kv.Value > 1.25) { reason=$"assignment {kv.Key}={kv.Value} outside artifact bounds"; return false; }
        }
        reason="validated against local constraint bounds"; return true;
    }
}
