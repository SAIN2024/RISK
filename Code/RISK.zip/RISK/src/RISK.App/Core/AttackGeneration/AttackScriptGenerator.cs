using RISK.Core.Domain;

namespace RISK.Core.AttackGeneration;

public sealed class AttackScriptGenerator
{
    public List<AttackScript> Generate(string testbed, Dictionary<string,double> patterns)
    {
        return testbed switch
        {
            "MP" => ManufacturingScripts(patterns),
            "CP" => ChemicalScripts(patterns),
            _ => WaterScripts(patterns)
        };
    }
    private static List<AttackScript> WaterScripts(Dictionary<string,double> p) => new()
    {
        new AttackScript{Id="WT-alpha-01", Testbed="WT", Goal="RecoveryInfeasible", ObservationHorizon=10, Stages=new(){
            new AttackStage{Name="pre-conditioning", Condition="L1 >= 80 && L1 < 84", Assignments=new(){["P1"]=0.70}, DurationSeconds=2},
            new AttackStage{Name="margin-compression", Condition="L1 >= 84 && L1 < 88", Assignments=new(){["MV1"]=0.80,["P1"]=0.50}, DurationSeconds=2},
            new AttackStage{Name="pre-alarm-push", Condition="L1 >= 88 && L1 < 90", Assignments=new(){["MV1"]=1.00,["P1"]=0.00}, DurationSeconds=1}}},
        new AttackScript{Id="WT-beta-02", Testbed="WT", Goal="RecoveryUnsafe", ObservationHorizon=16, Stages=new(){
            new AttackStage{Name="slow-fill", Condition="L1 >= 78 && L1 < 87", Assignments=new(){["MV1"]=0.65,["P1"]=0.35}, DurationSeconds=4},
            new AttackStage{Name="couple-downstream", Condition="L2 <= 32", Assignments=new(){["P2"]=1.00}, DurationSeconds=2}}}
    };
    private static List<AttackScript> ManufacturingScripts(Dictionary<string,double> p) => new()
    {
        new AttackScript{Id="MP-alpha-01",Testbed="MP",Goal="RecoveryInfeasible",ObservationHorizon=8,Stages=new(){
            new AttackStage{Name="speed-trim",Condition="Separation >= 45",Assignments=new(){["VGRSpeed"]=1.12},DurationSeconds=2},
            new AttackStage{Name="overlap-compress",Condition="Separation < 45",Assignments=new(){["MPOSpeed"]=0.88,["VGRSpeed"]=1.15},DurationSeconds=2}}},
        new AttackScript{Id="MP-beta-02",Testbed="MP",Goal="RecoveryUnsafe",ObservationHorizon=12,Stages=new(){
            new AttackStage{Name="payload-stress",Condition="PayloadStability >= 70",Assignments=new(){["VGRSpeed"]=1.18},DurationSeconds=3}}}
    };
    private static List<AttackScript> ChemicalScripts(Dictionary<string,double> p) => new()
    {
        new AttackScript{Id="CP-alpha-01",Testbed="CP",Goal="RecoveryUnsafe",ObservationHorizon=12,Stages=new(){
            new AttackStage{Name="heat-drift",Condition="Temp >= 70 && Temp < 86",Assignments=new(){["FeedRate"]=1.10,["Coolant"]=0.86},DurationSeconds=5},
            new AttackStage{Name="vent-load",Condition="Pressure >= 95",Assignments=new(){["VentRate"]=1.20},DurationSeconds=3}}},
        new AttackScript{Id="CP-beta-02",Testbed="CP",Goal="RecoveryInfeasible",ObservationHorizon=9,Stages=new(){
            new AttackStage{Name="pressure-ramp",Condition="Pressure >= 88 && Pressure < 100",Assignments=new(){["FeedRate"]=1.16,["Coolant"]=0.78},DurationSeconds=4}}}
    };
}
