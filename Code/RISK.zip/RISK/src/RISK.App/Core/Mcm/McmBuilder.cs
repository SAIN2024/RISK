using RISK.Core.Domain;

namespace RISK.Core.Mcm;

public sealed class McmBuilder
{
    public McmGraph Build(IEnumerable<ConstraintRule> constraints)
    {
        var g = new McmGraph(); g.Nodes.AddRange(constraints);
        foreach (var a in g.Nodes) foreach (var b in g.Nodes)
        {
            if (a==b) continue;
            if (a.RegulatedVariables.Intersect(b.RegulatedVariables, StringComparer.OrdinalIgnoreCase).Any()) g.Edges.Add(new McmEdge(a.Id,b.Id,"shared-variable"));
            else if (LayerRank(a.Layer)+1==LayerRank(b.Layer)) g.Edges.Add(new McmEdge(a.Id,b.Id,"layer-transition"));
            else if (!string.IsNullOrEmpty(a.BoundaryVariable) && a.BoundaryVariable.Equals(b.BoundaryVariable,StringComparison.OrdinalIgnoreCase) && a.Boundary <= b.Boundary) g.Edges.Add(new McmEdge(a.Id,b.Id,"boundary-order"));
        }
        return g;
    }
    private static int LayerRank(string l) => l.Contains("Control")?0:l.Contains("Detection")?1:2;
}
