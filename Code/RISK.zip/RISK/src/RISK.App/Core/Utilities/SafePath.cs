namespace RISK.Core.Utilities;

public static class SafePath
{
    public static string InsideBase(string baseDir, string name)
    {
        var full=Path.GetFullPath(Path.Combine(baseDir,name));
        if(!full.StartsWith(Path.GetFullPath(baseDir), StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Path escapes artifact directory");
        return full;
    }
}
