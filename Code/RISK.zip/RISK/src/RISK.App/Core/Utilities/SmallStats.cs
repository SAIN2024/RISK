namespace RISK.Core.Utilities;

public static class SmallStats
{
    public static double Mean(IEnumerable<double> xs){ var a=xs.ToArray(); return a.Length==0?0:a.Average(); }
    public static double Std(IEnumerable<double> xs){ var a=xs.ToArray(); if(a.Length<2) return 0; var m=a.Average(); return Math.Sqrt(a.Sum(x=>(x-m)*(x-m))/(a.Length-1)); }
}
