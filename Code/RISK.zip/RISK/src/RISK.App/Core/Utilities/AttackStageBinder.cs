namespace RISK.Core.Utilities;

public sealed class AttackStageBinder
{
    public string Name => "AttackStageBinder";
    public double Clamp(double value, double min, double max) => Math.Min(max, Math.Max(min, value));
    public bool Nearly(double a, double b, double eps = 1e-6) => Math.Abs(a-b) <= eps;
    public IEnumerable<double> MovingAverage(IEnumerable<double> values, int width = 3)
    {
        var q = new Queue<double>(); double sum = 0;
        foreach (var v in values) { q.Enqueue(v); sum += v; if (q.Count > width) sum -= q.Dequeue(); yield return sum / q.Count; }
    }
    public override string ToString() => "AttackStageBinder: small research helper used by the offline RISK artifact";
}
