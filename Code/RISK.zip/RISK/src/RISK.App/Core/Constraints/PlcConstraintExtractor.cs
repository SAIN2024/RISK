using RISK.Core.Domain;
using System.Text.RegularExpressions;

namespace RISK.Core.Constraints;

public sealed class PlcConstraintExtractor
{
    public List<ConstraintRule> ExtractFromFiles(IEnumerable<string> files)
    {
        var rules = new List<ConstraintRule>();
        int idx = 1;
        foreach (var f in files.Where(File.Exists))
        {
            var text = File.ReadAllText(f);
            foreach (Match m in Regex.Matches(text, @"IF\s+(?<cond>.*?)\s+THEN(?<act>.*?)(END_IF|ELSIF|ELSE)", RegexOptions.Singleline | RegexOptions.IgnoreCase))
            {
                var cond = Cleanup(m.Groups["cond"].Value); var act = Cleanup(m.Groups["act"].Value);
                var vars = Regex.Matches(act, @"(?<v>[A-Za-z][A-Za-z0-9_]*)\s*:=").Select(x=>x.Groups["v"].Value).Distinct().ToList();
                var boundary = ExtractBoundary(cond, out var bvar);
                rules.Add(new ConstraintRule { Id=$"C_PLC_{idx++}", Layer="Control", ConditionText=NormalizeCond(cond), ActionText=act, RegulatedVariables=vars, Boundary=boundary, BoundaryVariable=bvar });
            }
        }
        return rules;
    }
    private static string Cleanup(string s) => Regex.Replace(s.Replace("", " ").Replace("
", " "), @"\s+", " ").Trim();
    private static string NormalizeCond(string c) => c.Replace(":=", "=").Replace("AND", "&&", StringComparison.OrdinalIgnoreCase);
    private static double ExtractBoundary(string c, out string variable)
    {
        var m = Regex.Match(c, @"(?<v>[A-Za-z][A-Za-z0-9_]*)\s*(>=|>|<=|<|=)\s*(?<n>[0-9]+(\.[0-9]+)?)");
        variable = m.Success ? m.Groups["v"].Value : "";
        return m.Success ? double.Parse(m.Groups["n"].Value) : 0;
    }
}
