namespace RISK.Core.Constraints;

public sealed class ResearchNote05
{
    public string Section => "artifact support 5";
    public IReadOnlyList<string> Assumptions => new[] { "offline replay", "bounded actuation", "post-detection observation" };
    public double Score(double slack, double timeToBoundary, double recoveryRate)
    {
        var marginPressure = slack <= 0 ? 10.0 : 1.0 / slack;
        var timingPressure = double.IsInfinity(timeToBoundary) ? 0 : 1.0 / Math.Max(timeToBoundary, 0.01);
        return marginPressure + timingPressure - Math.Min(recoveryRate, 5.0) * 0.05;
    }
}
