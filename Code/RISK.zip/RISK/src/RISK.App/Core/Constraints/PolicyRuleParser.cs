using RISK.Core.Domain;
using System.Text.RegularExpressions;

namespace RISK.Core.Constraints;

public sealed class PolicyRuleParser
{
    public List<ConstraintRule> Parse(string path, string layer)
    {
        var rules = new List<ConstraintRule>(); if (!File.Exists(path)) return rules; int i=1;
        foreach (var line in File.ReadLines(path))
        {
            var t=line.Trim(); if (t.Length==0 || t.StartsWith("#")) continue;
            var parts=t.Split("=>", StringSplitOptions.TrimEntries); if (parts.Length!=2) continue;
            var vars=Regex.Matches(parts[1], @"(?<v>[A-Za-z][A-Za-z0-9_]*)\s*=").Select(m=>m.Groups["v"].Value).Distinct().ToList();
            var b=Boundary(parts[0], out var bv);
            rules.Add(new ConstraintRule{Id=$"C_{layer}_{i++}", Layer=layer, ConditionText=parts[0].Replace("AND","&&"), ActionText=parts[1], RegulatedVariables=vars, Boundary=b, BoundaryVariable=bv});
        }
        return rules;
    }
    private static double Boundary(string c, out string variable)
    {
        var m=Regex.Match(c,@"(?<v>[A-Za-z][A-Za-z0-9_]*)\s*(>=|>|<=|<|=)\s*(?<n>[0-9]+(\.[0-9]+)?)"); variable=m.Success?m.Groups["v"].Value:""; return m.Success?double.Parse(m.Groups["n"].Value):0;
    }
}
