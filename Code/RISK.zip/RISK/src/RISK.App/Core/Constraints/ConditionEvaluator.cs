using RISK.Core.Domain;
using System.Text.RegularExpressions;

namespace RISK.Core.Constraints;

public sealed class ConditionEvaluator
{
    public bool IsTrue(string condition, ProcessState s)
    {
        condition = condition.Trim();
        if (condition.Equals("true", StringComparison.OrdinalIgnoreCase)) return true;
        foreach (var part in condition.Split(new[]{"&&"}, StringSplitOptions.RemoveEmptyEntries))
            if (!EvalSimple(part.Trim(), s)) return false;
        return true;
    }
    private bool EvalSimple(string expr, ProcessState s)
    {
        if (expr.Equals("Alarm=1", StringComparison.OrdinalIgnoreCase) || expr.Equals("Alarm == 1", StringComparison.OrdinalIgnoreCase)) return s.Alarm;
        var m = Regex.Match(expr, @"(?<v>[A-Za-z0-9_]+)\s*(?<op>>=|<=|>|<|==|=)\s*(?<n>-?[0-9]+(\.[0-9]+)?)");
        if (!m.Success) return false;
        var v = s[m.Groups["v"].Value]; var n = double.Parse(m.Groups["n"].Value);
        return m.Groups["op"].Value switch { ">=" => v>=n, "<=" => v<=n, ">"=>v>n, "<"=>v<n, "=" or "==" => Math.Abs(v-n)<1e-9, _=>false};
    }
}
