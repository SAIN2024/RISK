using RISK.Core.Domain;

namespace RISK.Core.Vplc;

public interface IVplcRuntime
{
    string Name { get; }
    List<TracePoint> Execute(AttackScript script, double dt = 0.5);
}
