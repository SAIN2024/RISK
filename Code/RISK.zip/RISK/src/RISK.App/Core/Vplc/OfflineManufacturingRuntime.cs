using RISK.Core.Constraints;
using RISK.Core.Domain;

namespace RISK.Core.Vplc;

public sealed class OfflineManufacturingRuntime : IVplcRuntime
{
    public string Name => "offline:S7-1500V/manufacturing";
    private readonly ConditionEvaluator _eval = new();
    public List<TracePoint> Execute(AttackScript script, double dt = 0.25)
    {
        var s = new ProcessState { Time=0, AttackActive=true }; s["Separation"]=58; s["VGRSpeed"]=1.0; s["MPOSpeed"]=1.0; s["PayloadStability"]=92;
        var trace = new List<TracePoint>(); double recovery=-1;
        for(int k=0;k<90;k++)
        {
            foreach(var st in script.Stages) if(!s.Alarm && _eval.IsTrue(st.Condition,s)) foreach(var a in st.Assignments) s[a.Key]=a.Value;
            if ((s["Separation"] < 34 || s["VGRSpeed"]>1.14) && !s.Alarm) { s.Alarm=true; s.AttackActive=false; recovery=s.Time+0.6; }
            if(s.Alarm && s.Time>=recovery){ s["VGRSpeed"]=Approach(s["VGRSpeed"],0.65,0.04*dt); s["MPOSpeed"]=Approach(s["MPOSpeed"],0.70,0.04*dt); }
            var closing = (s["VGRSpeed"] + 0.8*s["MPOSpeed"])*5.2; s["Separation"] -= closing*dt; if(s.Alarm) s["Separation"] += 1.4*dt;
            s["PayloadStability"] -= Math.Max(0,s["VGRSpeed"]-1.0)*8*dt;
            trace.Add(ToPoint(s)); s.Time += dt; if(s.Time>script.ObservationHorizon+8) break;
        }
        return trace;
    }
    private static double Approach(double x,double target,double step)=> x<target?Math.Min(target,x+step):Math.Max(target,x-step);
    private static TracePoint ToPoint(ProcessState s)=>new(s.Time, s.Values.ToDictionary(k=>k.Key,v=>v.Value,StringComparer.OrdinalIgnoreCase), s.Alarm);
}
