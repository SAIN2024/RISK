using RISK.Core.Config;

namespace RISK.Core.Vplc;

public sealed class VplcRuntimeFactory
{
    private readonly VplcConfiguration _cfg;
    public VplcRuntimeFactory(VplcConfiguration cfg) { _cfg = cfg; }
    public IVplcRuntime Create(string testbed)
    {
        var path = _cfg.ResolveFor(testbed); // kept for audit trail; artifact uses local simulations only
        return testbed switch { "MP" => new OfflineManufacturingRuntime(), "CP" => new OfflineChemicalRuntime(), _ => new OfflineWaterTreatmentRuntime() };
    }
}
