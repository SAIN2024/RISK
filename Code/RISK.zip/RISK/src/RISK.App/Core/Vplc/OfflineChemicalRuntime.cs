using RISK.Core.Constraints;
using RISK.Core.Domain;

namespace RISK.Core.Vplc;

public sealed class OfflineChemicalRuntime : IVplcRuntime
{
    public string Name => "offline:PLCnext/chemical";
    private readonly ConditionEvaluator _eval = new();
    public List<TracePoint> Execute(AttackScript script, double dt = 0.5)
    {
        var s = new ProcessState { Time=0, AttackActive=true }; s["Temp"]=72; s["Pressure"]=85; s["FeedRate"]=1.0; s["Coolant"]=1.0; s["VentRate"]=0.45; s["Neutralizer"]=100;
        var trace=new List<TracePoint>(); double recovery=-1;
        for(int k=0;k<110;k++)
        {
            foreach(var st in script.Stages) if(!s.Alarm && _eval.IsTrue(st.Condition,s)) foreach(var a in st.Assignments) s[a.Key]=a.Value;
            if((s["Temp"]>=88 || s["Pressure"]>=100) && !s.Alarm){s.Alarm=true;s.AttackActive=false; recovery=s.Time+1.0;}
            if(s.Alarm && s.Time>=recovery){ s["FeedRate"]=Approach(s["FeedRate"],0.40,0.08*dt); s["Coolant"]=Approach(s["Coolant"],1.20,0.07*dt); s["VentRate"]=Approach(s["VentRate"],1.15,0.05*dt);}
            s["Temp"] += (2.2*s["FeedRate"] - 1.4*s["Coolant"] - 0.15)*dt;
            s["Pressure"] += (1.7*s["FeedRate"] + Math.Max(0,s["Temp"]-86)*0.12 - 1.0*s["VentRate"])*dt;
            if(s["VentRate"]>0.8) s["Neutralizer"] -= (s["VentRate"]*4.5)*dt;
            trace.Add(ToPoint(s)); s.Time+=dt; if(s.Time>script.ObservationHorizon+20) break;
        }
        return trace;
    }
    private static double Approach(double x,double target,double step)=> x<target?Math.Min(target,x+step):Math.Max(target,x-step);
    private static TracePoint ToPoint(ProcessState s)=>new(s.Time, s.Values.ToDictionary(k=>k.Key,v=>v.Value,StringComparer.OrdinalIgnoreCase), s.Alarm);
}
