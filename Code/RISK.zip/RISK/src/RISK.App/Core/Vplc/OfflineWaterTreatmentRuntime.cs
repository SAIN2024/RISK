using RISK.Core.Constraints;
using RISK.Core.Domain;

namespace RISK.Core.Vplc;

public sealed class OfflineWaterTreatmentRuntime : IVplcRuntime
{
    public string Name => "offline:CODESYS-SL/water";
    private readonly ConditionEvaluator _eval = new();
    public List<TracePoint> Execute(AttackScript script, double dt = 0.5)
    {
        var s = new ProcessState { Time=0, AttackActive=true }; s["L1"]=80; s["L2"]=35; s["MV1"]=0.48; s["P1"]=0.40; s["P2"]=0.20;
        var trace = new List<TracePoint>(); double recoveryStart=-1;
        for(int k=0;k<80;k++)
        {
            foreach(var stage in script.Stages) if(!s.Alarm && _eval.IsTrue(stage.Condition,s)) foreach(var a in stage.Assignments) s[a.Key]=a.Value;
            if (s["L1"] >= 90 && !s.Alarm) { s.Alarm=true; s.AttackActive=false; recoveryStart=s.Time+1.0; }
            if (s.Alarm && s.Time>=recoveryStart) { s["MV1"] = Approach(s["MV1"], 0.0, 0.18*dt); s["P1"] = Approach(s["P1"], 1.0, 0.12*dt); if(s["L2"]<30) s["P2"]=Approach(s["P2"],1.0,0.15*dt); }
            var inflow = 3.0*s["MV1"]; var drain = 1.2*s["P1"]; var transfer = 0.5*s["P2"];
            if (s.Alarm && s.Time < recoveryStart + 3.0) inflow += 0.55; // valve closure lag
            s["L1"] += (inflow - drain - transfer)*dt; s["L2"] += (transfer - 0.38*s["P2"])*dt;
            trace.Add(ToPoint(s)); s.Time += dt; if (s.Time > script.ObservationHorizon + 12) break;
        }
        return trace;
    }
    private static double Approach(double x,double target,double step)=> x<target?Math.Min(target,x+step):Math.Max(target,x-step);
    private static TracePoint ToPoint(ProcessState s)=>new(s.Time, s.Values.ToDictionary(k=>k.Key,v=>v.Value,StringComparer.OrdinalIgnoreCase), s.Alarm);
}
