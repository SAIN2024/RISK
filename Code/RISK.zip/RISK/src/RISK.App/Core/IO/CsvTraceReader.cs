using RISK.Core.Domain;

namespace RISK.Core.IO;

public sealed class CsvTraceReader
{
    public List<TracePoint> Read(string path)
    {
        var lines = File.ReadAllLines(path).Where(l=>!string.IsNullOrWhiteSpace(l)).ToList();
        if (lines.Count < 2) return new();
        var header = lines[0].Split(',').Select(h=>h.Trim()).ToArray();
        var result = new List<TracePoint>();
        foreach (var line in lines.Skip(1))
        {
            var parts = line.Split(','); var vals = new Dictionary<string,double>(StringComparer.OrdinalIgnoreCase);
            double time = 0; bool alarm = false;
            for (int i=0;i<Math.Min(header.Length, parts.Length);i++)
            {
                if (header[i].Equals("Time", StringComparison.OrdinalIgnoreCase)) double.TryParse(parts[i], out time);
                else if (header[i].Equals("Alarm", StringComparison.OrdinalIgnoreCase)) alarm = parts[i].Trim()=="1" || parts[i].Trim().Equals("true", StringComparison.OrdinalIgnoreCase);
                else if (double.TryParse(parts[i], out var v)) vals[header[i]] = v;
            }
            result.Add(new TracePoint(time, vals, alarm));
        }
        return result;
    }
}
