namespace RISK.Core.IO;

public static class SampleLocator
{
    public static string Base => Path.Combine(AppContext.BaseDirectory, "Data", "Samples");
    public static string Plc(string name) => Path.Combine(Base, "PLC", name);
    public static string Policy(string name) => Path.Combine(Base, "Policies", name);
    public static string Trace(string name) => Path.Combine(Base, "Traces", name);
    public static IEnumerable<string> Testbeds() => new[] { "MP", "CP", "WT" };
}
