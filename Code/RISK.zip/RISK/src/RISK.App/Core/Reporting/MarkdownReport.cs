using RISK.Core.Domain;
using System.Text;

namespace RISK.Core.Reporting;

public static class MarkdownReport
{
    public static string FromList(IEnumerable<RecoveryOutcome> outcomes)
    {
        var sb = new StringBuilder();
        sb.AppendLine("# RISK Artifact Report"); sb.AppendLine();
        sb.AppendLine("This report is produced by the local offline artifact pipeline. It records only simulated vPLC executions and does not contact a real controller.");
        sb.AppendLine(); sb.AppendLine("| Testbed | Script | t_d | t_c | Classification | Reason |"); sb.AppendLine("|---|---:|---:|---:|---|---|");
        foreach(var o in outcomes) sb.AppendLine($"| {o.Testbed} | {o.ScriptId} | {o.RecoveryStart:0.00} | {o.RecoveryComplete:0.00} | {o.Classification} | {o.Explanation.Replace("|","/")} |");
        return sb.ToString();
    }
}
