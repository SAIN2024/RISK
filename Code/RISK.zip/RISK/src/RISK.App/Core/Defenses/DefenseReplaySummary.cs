namespace RISK.Core.Defenses;

public sealed class DefenseReplaySummary
{
    public string DefenseName { get; init; } = "SAIN-style invariant monitor";
    public int DetectedBeforeTltr { get; set; }
    public int DetectedAfterTltr { get; set; }
    public double BlockRate => (DetectedBeforeTltr + DetectedAfterTltr) == 0 ? 0 : (double)DetectedBeforeTltr/(DetectedBeforeTltr+DetectedAfterTltr);
    public override string ToString() => $"{DefenseName}: early-block={BlockRate:P1}";
}
