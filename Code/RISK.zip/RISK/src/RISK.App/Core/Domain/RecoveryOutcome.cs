namespace RISK.Core.Domain;

public enum RecoveryClassification { Recoverable, Infeasible, Unsafe }
public sealed class RecoveryOutcome
{
    public string Testbed { get; init; } = "";
    public string ScriptId { get; init; } = "";
    public RecoveryClassification Classification { get; init; }
    public double RecoveryStart { get; init; }
    public double RecoveryComplete { get; init; }
    public string Explanation { get; init; } = "";
    public List<TracePoint> Trace { get; init; } = new();
}
