namespace RISK.Core.Domain;

public sealed class McmGraph
{
    public List<ConstraintRule> Nodes { get; } = new();
    public List<McmEdge> Edges { get; } = new();
    public IEnumerable<string> RecoveryVariables => Nodes.Where(n=>n.IsRecoveryRule).SelectMany(n=>n.RegulatedVariables).Distinct(StringComparer.OrdinalIgnoreCase);
}
public sealed record McmEdge(string From, string To, string Reason);
