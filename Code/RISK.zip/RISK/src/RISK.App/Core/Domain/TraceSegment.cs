namespace RISK.Core.Domain;

public sealed class TraceSegment
{
    public string SegmentId { get; init; } = "S";
    public ConstraintRule Constraint { get; init; } = new();
    public List<TracePoint> Points { get; init; } = new();
    public double MinimumSlack { get; set; }
    public double TimeToBoundary { get; set; }
    public double RecoveryRate { get; set; }
    public override string ToString() => $"{SegmentId}: {Constraint.Id} D={MinimumSlack:0.###}, T={TimeToBoundary:0.###}, R={RecoveryRate:0.###}";
}
