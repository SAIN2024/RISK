namespace RISK.Core.Domain;

public sealed class ProcessState
{
    private readonly Dictionary<string,double> _values = new(StringComparer.OrdinalIgnoreCase);
    public double Time { get; set; }
    public bool Alarm { get; set; }
    public bool AttackActive { get; set; }
    public IReadOnlyDictionary<string,double> Values => _values;
    public double this[string name] { get => _values.TryGetValue(name, out var v) ? v : 0.0; set => _values[name] = value; }
    public ProcessState Clone() { var c = new ProcessState{Time=Time,Alarm=Alarm,AttackActive=AttackActive}; foreach(var kv in _values) c[kv.Key]=kv.Value; return c; }
    public override string ToString() => $"t={Time:0.0}, alarm={Alarm}, " + string.Join(", ", _values.Select(kv=>$"{kv.Key}={kv.Value:0.###}"));
}
