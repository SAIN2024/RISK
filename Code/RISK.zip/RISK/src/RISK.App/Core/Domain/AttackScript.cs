namespace RISK.Core.Domain;

public sealed class AttackScript
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N")[..8];
    public string Testbed { get; init; } = "WT";
    public string Goal { get; init; } = "RecoveryInfeasible";
    public double ObservationHorizon { get; init; } = 10;
    public List<AttackStage> Stages { get; init; } = new();
    public override string ToString() => $"{Id} ({Testbed}/{Goal}) stages={Stages.Count}, H={ObservationHorizon}";
}
public sealed class AttackStage
{
    public string Name { get; init; } = "stage";
    public string Condition { get; init; } = "true";
    public Dictionary<string,double> Assignments { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    public double DurationSeconds { get; init; } = 1;
}
