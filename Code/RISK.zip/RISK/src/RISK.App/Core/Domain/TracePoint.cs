namespace RISK.Core.Domain;

public sealed record TracePoint(double Time, Dictionary<string,double> Values, bool Alarm=false)
{
    public double Get(string key) => Values.TryGetValue(key, out var v) ? v : 0;
}
