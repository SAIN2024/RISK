namespace RISK.Core.Domain;

public sealed class ConstraintRule
{
    public string Id { get; init; } = "C";
    public string Layer { get; init; } = "Control";
    public string ConditionText { get; init; } = "true";
    public string ActionText { get; init; } = "";
    public List<string> RegulatedVariables { get; init; } = new();
    public double Boundary { get; init; }
    public string BoundaryVariable { get; init; } = "";
    public bool IsRecoveryRule => Layer.Contains("Supervisory", StringComparison.OrdinalIgnoreCase) || Layer.Contains("Recovery", StringComparison.OrdinalIgnoreCase);
    public override string ToString() => $"{Id} [{Layer}] if {ConditionText} -> {ActionText}";
}
