using RISK.Core.Domain;

namespace RISK.Core.TraceAnalysis;

public sealed class TracePartitioner
{
    private readonly SlackCalculator _slack = new();
    public List<TraceSegment> Partition(List<TracePoint> trace, IEnumerable<ConstraintRule> constraints)
    {
        var result = new List<TraceSegment>(); int sid=1;
        foreach (var c in constraints.Where(x=>x.Boundary>0).OrderBy(x=>x.Boundary))
        {
            var pts = trace.Where(p => Math.Abs(p.Get(c.BoundaryVariable)-c.Boundary) <= 12 || (p.Get(c.BoundaryVariable) <= c.Boundary && p.Get(c.BoundaryVariable)>=c.Boundary-20)).ToList();
            if (pts.Count==0) pts = trace.OrderBy(p=>Math.Abs(_slack.Slack(p,c,100))).Take(Math.Min(5, trace.Count)).OrderBy(p=>p.Time).ToList();
            var seg = new TraceSegment { SegmentId=$"S{sid++}", Constraint=c, Points=pts };
            FillMetrics(seg); result.Add(seg);
        }
        return result;
    }
    private void FillMetrics(TraceSegment seg)
    {
        if (seg.Points.Count==0) return;
        var c=seg.Constraint; var variable=string.IsNullOrWhiteSpace(c.BoundaryVariable)?"L1":c.BoundaryVariable;
        var slacks=seg.Points.Select(p=>_slack.Slack(p,c,100)).ToList();
        seg.MinimumSlack=slacks.Min();
        var rate=_slack.Rate(seg.Points, variable);
        seg.TimeToBoundary=Math.Abs(rate)<1e-6 ? double.PositiveInfinity : Math.Abs(seg.MinimumSlack/rate);
        seg.RecoveryRate=EstimateRecoveryRate(seg.Points, variable);
    }
    private static double EstimateRecoveryRate(IReadOnlyList<TracePoint> pts, string variable)
    {
        double best=0;
        for(int i=1;i<pts.Count;i++){ var dt=pts[i].Time-pts[i-1].Time; if(dt<=0) continue; var r=(pts[i-1].Get(variable)-pts[i].Get(variable))/dt; if(r>best) best=r; }
        return best;
    }
}
