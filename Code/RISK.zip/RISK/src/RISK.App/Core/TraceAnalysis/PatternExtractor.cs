using RISK.Core.Domain;

namespace RISK.Core.TraceAnalysis;

public sealed class PatternExtractor
{
    public Dictionary<string,double> Summarize(IEnumerable<TraceSegment> segments)
    {
        var list=segments.ToList();
        return new Dictionary<string,double> {
            ["min_slack"] = list.Count==0?0:list.Min(s=>s.MinimumSlack),
            ["median_time_to_boundary"] = Median(list.Select(s=>double.IsInfinity(s.TimeToBoundary)?999:s.TimeToBoundary)),
            ["max_recovery_rate"] = list.Count==0?0:list.Max(s=>s.RecoveryRate),
            ["segment_count"] = list.Count
        };
    }
    private static double Median(IEnumerable<double> xs){ var a=xs.OrderBy(x=>x).ToArray(); if(a.Length==0) return 0; return a[a.Length/2];}
}
