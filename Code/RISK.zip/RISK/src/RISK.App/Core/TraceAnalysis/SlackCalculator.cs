using RISK.Core.Domain;

namespace RISK.Core.TraceAnalysis;

public sealed class SlackCalculator
{
    public double Slack(TracePoint p, ConstraintRule c, double safetyLimitFallback)
    {
        var variable = string.IsNullOrWhiteSpace(c.BoundaryVariable) ? "L1" : c.BoundaryVariable;
        var boundary = c.Boundary > 0 ? c.Boundary : safetyLimitFallback;
        return boundary - p.Get(variable);
    }
    public double Rate(IReadOnlyList<TracePoint> pts, string variable)
    {
        if (pts.Count < 2) return 0;
        var first=pts.First(); var last=pts.Last(); var dt=Math.Max(1e-9,last.Time-first.Time); return (last.Get(variable)-first.Get(variable))/dt;
    }
}
