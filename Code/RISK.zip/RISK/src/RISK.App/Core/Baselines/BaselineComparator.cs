namespace RISK.Core.Baselines;

public sealed class BaselineComparator
{
    public double EstimateTltrRate(string method, int tltr, int total) => total <= 0 ? 0 : (double)tltr / total;
    public string Compare(double riskRate, double baselineRate) => riskRate > baselineRate ? $"RISK improves TLTR yield by {(riskRate-baselineRate)*100:0.0} percentage points" : "Baseline did not underperform on this sample";
}
