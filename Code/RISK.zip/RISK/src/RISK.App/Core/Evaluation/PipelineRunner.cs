using RISK.Core.AttackGeneration;
using RISK.Core.Config;
using RISK.Core.Constraints;
using RISK.Core.Domain;
using RISK.Core.IO;
using RISK.Core.Mcm;
using RISK.Core.Recovery;
using RISK.Core.TraceAnalysis;
using RISK.Core.Vplc;

namespace RISK.Core.Evaluation;

public sealed class PipelineRunner
{
    private readonly VplcConfiguration _cfg; private readonly Action<string> _log;
    public List<RecoveryOutcome> LastOutcomes { get; } = new();
    public PipelineRunner(VplcConfiguration cfg, Action<string> log) { _cfg=cfg; _log=log; }
    public List<RecoveryOutcome> RunAll()
    {
        LastOutcomes.Clear();
        foreach(var testbed in SampleLocator.Testbeds()) RunOne(testbed);
        _log($"Complete: {LastOutcomes.Count} executions, TLTR={LastOutcomes.Count(o=>o.Classification!=RecoveryClassification.Recoverable)}");
        return LastOutcomes.ToList();
    }
    private void RunOne(string testbed)
    {
        _log($"[{testbed}] loading PLC, detection, recovery policies, and normal traces");
        var extractor=new PlcConstraintExtractor(); var parser=new PolicyRuleParser();
        var plc=Directory.GetFiles(Path.Combine(SampleLocator.Base,"PLC"), $"{testbed}_*.st");
        var constraints = new List<ConstraintRule>(); constraints.AddRange(extractor.ExtractFromFiles(plc));
        constraints.AddRange(parser.Parse(SampleLocator.Policy($"{testbed}_detection.rules"), "Detection"));
        constraints.AddRange(parser.Parse(SampleLocator.Policy($"{testbed}_recovery.rules"), "Supervisory"));
        _log($"[{testbed}] constraints extracted: {constraints.Count}");
        var mcm = new McmBuilder().Build(constraints); _log($"[{testbed}] MCM nodes={mcm.Nodes.Count}, edges={mcm.Edges.Count}");
        var traceFile = SampleLocator.Trace($"{testbed}_normal.csv"); var trace = new CsvTraceReader().Read(traceFile);
        var segments = new TracePartitioner().Partition(trace, constraints); foreach(var s in segments.Take(3)) _log($"[{testbed}] pattern {s}");
        var patterns = new PatternExtractor().Summarize(segments);
        var scripts = new AttackScriptGenerator().Generate(testbed, patterns); var validator=new AttackValidator(); var runtime=new VplcRuntimeFactory(_cfg).Create(testbed); var analyzer=new RecoveryAnalyzer();
        _log($"[{testbed}] using {runtime.Name}; scripts proposed={scripts.Count}");
        foreach(var script in scripts)
        {
            if(!validator.Validate(script,mcm,out var why)){ _log($"[{testbed}] script {script.Id} rejected: {why}"); continue; }
            var runTrace=runtime.Execute(script); var outcome=analyzer.Analyze(testbed, script, runTrace, mcm); LastOutcomes.Add(outcome);
            _log($"[{testbed}] {script.Id}: {outcome.Classification} ({outcome.Explanation})");
        }
    }
}
