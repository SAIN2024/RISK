using RISK.Core.Domain;

namespace RISK.Core.Recovery;

public sealed record ConstraintViolation(string ConstraintId, double Time, List<string> Variables, string Detail);

public sealed class ViolationDetector
{
    public List<ConstraintViolation> Detect(string testbed, IReadOnlyList<TracePoint> trace)
    {
        var list = new List<ConstraintViolation>();
        foreach(var p in trace)
        {
            if(testbed=="WT") { if(p.Get("L1")>100) list.Add(new("WT_MAX_L1",p.Time,new(){"MV1","P1"},$"L1 exceeded tank capacity ({p.Get("L1"):0.0})")); if(p.Get("L2")<20) list.Add(new("WT_MIN_L2",p.Time,new(){"P2"},"downstream level below minimum")); }
            if(testbed=="MP") { if(p.Get("Separation")<20) list.Add(new("MP_COLLISION_MARGIN",p.Time,new(){"VGRSpeed","MPOSpeed"},$"robot separation {p.Get("Separation"):0.0} cm")); if(p.Get("PayloadStability")<55) list.Add(new("MP_PAYLOAD",p.Time,new(){"VGRSpeed"},"payload stability violated")); }
            if(testbed=="CP") { if(p.Get("Pressure")>112) list.Add(new("CP_PRESSURE",p.Time,new(){"FeedRate","VentRate"},"reactor pressure exceeded bound")); if(p.Get("Neutralizer")<15) list.Add(new("CP_SCRUBBER",p.Time,new(){"VentRate"},"scrubber neutralizer depleted")); }
        }
        return list;
    }
}
