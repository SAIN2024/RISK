using RISK.Core.Domain;

namespace RISK.Core.Recovery;

public sealed class RecoveryAnalyzer
{
    private readonly ViolationDetector _violations = new();
    public RecoveryOutcome Analyze(string testbed, AttackScript script, List<TracePoint> trace, McmGraph mcm)
    {
        var td = GetRecoveryInitiationTime(trace);
        var tc = EstimateRecoveryCompletionTime(testbed, trace, td);
        var recoveryVars = mcm.RecoveryVariables.ToHashSet(StringComparer.OrdinalIgnoreCase);
        if(recoveryVars.Count==0) recoveryVars = DefaultRecoveryVars(testbed);
        foreach (var v in _violations.Detect(testbed, trace).OrderBy(v=>v.Time))
        {
            if(!v.Variables.Any(x=>recoveryVars.Contains(x))) continue;
            if(v.Time >= td && v.Time < tc) return Outcome(testbed, script, RecoveryClassification.Infeasible, td, tc, v.Detail, trace);
            if(v.Time >= tc) return Outcome(testbed, script, RecoveryClassification.Unsafe, td, tc, v.Detail, trace);
        }
        return Outcome(testbed, script, RecoveryClassification.Recoverable, td, tc, "No recovery-related violation in the observation horizon", trace);
    }
    private static double GetRecoveryInitiationTime(List<TracePoint> t) => t.FirstOrDefault(p=>p.Alarm)?.Time ?? double.PositiveInfinity;
    private static double EstimateRecoveryCompletionTime(string testbed, List<TracePoint> trace, double td)
    {
        if(double.IsInfinity(td)) return double.PositiveInfinity;
        if(testbed=="WT") return td+4.0; if(testbed=="MP") return td+2.0; return td+6.0;
    }
    private static HashSet<string> DefaultRecoveryVars(string testbed) => testbed switch { "WT" => new(StringComparer.OrdinalIgnoreCase){"MV1","P1","P2"}, "MP" => new(StringComparer.OrdinalIgnoreCase){"VGRSpeed","MPOSpeed"}, _ => new(StringComparer.OrdinalIgnoreCase){"FeedRate","Coolant","VentRate"} };
    private static RecoveryOutcome Outcome(string t, AttackScript s, RecoveryClassification c, double td, double tc, string reason, List<TracePoint> trace) => new(){Testbed=t,ScriptId=s.Id,Classification=c,RecoveryStart=td,RecoveryComplete=tc,Explanation=reason,Trace=trace};
}
