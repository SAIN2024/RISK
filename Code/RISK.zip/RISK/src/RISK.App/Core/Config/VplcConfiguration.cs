namespace RISK.Core.Config;

public sealed record VplcConfiguration(string SiemensPath, string PlcNextPath, string CodesysPath, bool AllowOfflineSimulation)
{
    public static VplcConfiguration CreateDefault() => new("", "", "", true);
    public string ResolveFor(string testbed) => testbed switch
    {
        "MP" => string.IsNullOrWhiteSpace(SiemensPath) ? "offline:S7-1500V" : SiemensPath,
        "CP" => string.IsNullOrWhiteSpace(PlcNextPath) ? "offline:PLCnext" : PlcNextPath,
        _ => string.IsNullOrWhiteSpace(CodesysPath) ? "offline:CODESYS-SL" : CodesysPath
    };
}
