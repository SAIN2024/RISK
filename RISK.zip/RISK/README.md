# RISK Recovery Audit

Artifact version 1.2.0. RISK measures where a configured recovery procedure
stops achieving its physical objective. This release provides an offline
recovery-audit engine, a Windows desktop interface, and a reproducible
synthetic example.

## Quick start on Windows x64

Extract the entire archive. Open `Windows-x64\Risk.Desktop.exe`, select
**Use sample project**, then **Run audit**. When the run finishes, select
**View report** for the HTML summary or **Open report folder** for the full
JSON output. The executable includes the .NET Desktop runtime. The sample
runs offline and requires no credentials, PLC software, or cloud service.

For a check with an exit status, open PowerShell in the extracted folder:

```powershell
.\Windows-x64\Risk.Cli.exe verify
```

The verifier returns exit code 0 after printing `PASS` and the paths to
the JSON and HTML reports. A CSV of the simulation traces is saved alongside them. It executes the same audit engine as the desktop app and checks
the expected results below. Pass an optional output folder after `verify`
to save the reports elsewhere. A reference run is included in
`sample-report/`.

## Expected sample results

The bundled system is an animation-job queue with a finite buffer.

| Check | Expected result |
| --- | --- |
| Artifact coverage | A synthetic hazard without an associated recovery procedure is reported as a coverage gap. |
| Baseline paired trials | With 2 queued jobs, the recovery routine reaches physical completion. With 6 queued jobs, the buffer reaches its limit before completion. The failed starting snapshot is below the hazard threshold. |
| Recorded baseline timeline | The failed witness is observed before hazard onset. The hazard occurs after the recorded external input ends. |
| Counterfactual | Reducing one modeled parameter restores recovery at the original failure snapshot. |
| Modified model | Both original witnesses recover, and the nominal test passes. The supplied modified recording reaches completion. |

The results establish a local bracket for the tested operating context. The
modified run evaluates the same snapshots, so recovery at both points does
not locate a new boundary.

## Scope relative to the paper

| Paper section | Artifact coverage |
| --- | --- |
| §5.1 | Normalized procedure inputs, line-level grounding against engineering text, and explicit outcomes for missing or unmatched source references. |
| §5.2 | Candidate selection and paired closed-loop trials from supplied snapshots. The engine distinguishes hazards, completion, exhausted continuations, expired deployment deadlines, and unresolved horizons. |
| §5.3 | Review of supplied timelines for an observed failure witness, recovery initiation, input cessation, and physical outcome. The recorder's protection status is an input attestation. |
| §5.4 | Single-factor replay from the original failed snapshot. |
| §5.5 | Modified-model recovery trials, baseline and modified nominal comparisons, and review of supplied variant recordings. |

This release demonstrates the workflow on synthetic data. Reproducing the paper's
plant experiments requires the original PLC programs, models, traces, and
configurations. The release provides a simulator interface for custom offline
models. Vendor vPLC adapters, ST/SCL extraction, and attack generation and
execution are outside its scope. Recorded evidence is reviewed as supplied.

## Audit another deployment

Copy `examples/demo/` to a writable folder. Replace the sample manifest, model,
snapshots, and engineering references with your own. Select the resulting
`project.json` in the desktop app. See [INPUTS.md](INPUTS.md) for the input
contract, simulator adapter interface, and optional provider configuration.

Check the input files and references before running the audit:

```powershell
.\Windows-x64\Risk.Cli.exe check .\examples\demo\project.json
.\Windows-x64\Risk.Cli.exe audit .\examples\demo\project.json .\reports
```

The input check validates JSON, model configuration, and source references without
running simulations or using the configured LLM endpoint.

| Output | Contents |
| --- | --- |
| `summary.html` | Recovery, evidence, diagnosis, and mitigation results. |
| `report.json` | The full report with source references, eligible and evaluated hypotheses, simulated traces, and input hashes. |
| `trajectories.csv` | One row per simulated state variable per sample, keyed by phase, variant, case, witness, and time in seconds. CSV labels that could be interpreted as spreadsheet formulas are escaped. The JSON preserves the original identifiers. |

Each successful audit publishes all three files in a new directory.

## Build from source

Install the .NET 10 SDK. The repository has no third-party package dependencies.
The SDK may obtain the Microsoft Windows targeting and runtime packs.

```powershell
dotnet build .\RISK.sln -c Release -m:1
dotnet run --project .\tests\Risk.Regression -c Release
dotnet run --project .\src\Risk.Cli -c Release -- verify .\reports
dotnet run --project .\src\Risk.Desktop -c Release
dotnet publish .\src\Risk.Desktop -c Release -r win-x64 --self-contained true -o .\publish\desktop
dotnet publish .\src\Risk.Cli -c Release -r win-x64 --self-contained true -o .\publish\cli
```

The CLI and audit engine can also be built and run on Linux using the same SDK.

## Source layout

| Location | Responsibility |
| --- | --- |
| `src/Risk.Core/Inputs` | Input parsing, provenance, model validation, and candidate scans. |
| `src/Risk.Core/Simulation` | Trial execution, predicates, declarative simulation, and adapter loading. |
| `src/Risk.Core/Auditing` | Boundary tests, recorded evidence review, counterfactuals, and mitigation comparisons. |
| `src/Risk.Core/Hypotheses` | Hypothesis selection and optional provider transport. |
| `src/Risk.Core/Reporting` | JSON, HTML, and CSV export. |
| `src/Risk.Cli` and `src/Risk.Desktop` | Command-line and Windows Forms entry points for the same engine. |
| `tests/Risk.Regression` | Regression checks using variations of the packaged example. |
