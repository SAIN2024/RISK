# Project input reference

Use UTF-8 JSON and the property names in the sample. Duplicate property names are rejected. Paths are relative to
`project.json`. Audit configuration, source identifiers, limits, scan periods,
initial states, and model parameters come from inputs. IDs are case-sensitive.
A predicate is a conjunction of comparisons. Each comparison is
`{"variable":"backlog","op":"ge","value":12}`. Operators are
`lt`, `le`, `eq`, `ne`, `ge`, and `gt`. Encode booleans, timers, and
operating modes as numeric state variables. Test sampled analog values using
ranges where appropriate. Each recorded state must provide every declared
variable as a finite number.

## Manifest

| Field | Content |
| --- | --- |
| `name` | Human-readable name used in the report. |
| `model` | Path to the baseline simulation description. |
| `artifacts` | Map from ID to text file path, such as exported controller code, specifications, protections, or operations logs. |
| `procedures` | Entries with `id`, `objective`, `sources`, `hazard`, `trigger`, `completion`, `doneVariable`, optional `exhaustedVariable`, `horizonSteps`, and optional `deadlineSteps`. Supply an empty `trigger` for procedures invoked manually. List a hazard with empty `sources` when a deployed procedure is missing. The deadline is the time limit declared by the deployment in scans. The horizon is the maximum observation length in scans. |
| `snapshots` | Entries with `id`, complete `state`, and `source`. Supply observed or simulated reachable snapshots, including actuator state, controller state, and timing where required. The app verifies the reference and state schema. The auditor establishes that the state is reachable and the referenced evidence supports it. |
| `candidates` | Explicit pairs with `id`, `procedure`, `coordinate`, `safeSnapshot`, `failedSnapshot`, and `context`. The latter two names indicate hypotheses until the run establishes their outcomes. Other changed state variables are listed in JSON. |
| `scans` | Optional entries with `id`, `procedure`, `coordinate`, 2–1,000 snapshot IDs in `snapshots`, `context`, and `failureAtHigherValue`. Groups eligible snapshots by matching non-coordinate state, then compares adjacent coordinates. Generated candidate IDs have the format `scan-id/safe-snapshot-id/failed-snapshot-id`. |
| `interventions` | Entries with `id`, `candidate`, model `parameter`, replacement `value`, `explanation`, and `source`. One parameter changes per replay. |
| `variants` | Entries with `id`, `description`, path to the variant `model`, and `source`. Optional `triggerOverrides` maps procedure IDs to ordinary trigger predicates so earlier intervention can be tested. Immediate recovery trials still bypass ordinary triggering. Baseline and variant models share the state interface and physical objectives. Supply extra snapshots if you need to locate a shifted boundary. |
| `nominalCases` | Entries with `id`, `procedure`, `snapshot`, `steps`, and endpoint `expected` predicates. Uses ordinary triggering and checks the hazard throughout the run. Select the referenced procedure to evaluate its corresponding hazard. |
| `evidence` | Optional path to prior recordings in the format below. |
| `llm` | Optional selection mode and provider settings below. |

Required collections can be empty. Each `source` and each entry in `sources`
has `artifact` (the ID), `line` (one-based), and `quote` (a literal substring
on that line). Grounding verifies the link and quote. Engineering review is
required to establish the semantic relationship between the source and the
normalized specification.

## Simulator model

`model.json` contains a positive `stepSeconds`, named numeric `parameters`,
and a list of `variables`. The built-in discrete simulator applies the
selected controller rule list in order each scan. Each rule has `when` (a
predicate, or an empty array for an unconditional rule) and `set` (literal
assignments). `nominalRules` are used during normal operation and
`recoveryRules` maps each procedure ID to its rule list. Each recovery rule
list should include any protection logic that remains active during recovery.
Earlier rules can affect later guards within the same scan.

For each item in `rates`, the simulator simultaneously applies one forward
Euler update to its `variable` after evaluating the rules. The derivative
is `constant` plus `stateTerms` (variable coefficients) and `parameterTerms`
(parameter coefficients). Variables without a rate retain their assigned value.
Select the step from the validated timing needs of your plant model and
account for scan resolution in interpreting results. Procedure state should
hold the deployed timer, guards, and physical completion indicators.

At the initial sample and every subsequent scan, the harness checks the
hazard first. A hazard and completion at the same sample result in a failure.
The harness requires a fresh scan after initiation before accepting a done
flag and physical completion. An exhausted continuation or expired deployment
deadline is a failure. A finite observation horizon with pending recovery is
unresolved. Mitigation reruns use the original snapshots. Changing the state
representation requires preparing equivalent snapshots before audit.

### Custom virtual PLC and plant adapter

For a nonlinear simulator, a different integration method, or a vendor vPLC,
create a .NET 10 class library referencing `Risk.Core`. Implement its public
`IOfflineSimulator` interface with a public parameterless constructor. Bind
the assembly relative to the project directory:

```json
"adapter": {
  "assembly": "adapters/DeploymentSimulator.dll",
  "type": "Deployment.DeploymentSimulator"
}
```

Leave `nominalRules` and `rates` as empty arrays and `recoveryRules` as an
empty object for an adapter model. Baseline/variant models can have different
adapters. The loader reads the specified DLL and resolves framework and host
assemblies. Additional dependency loading is the adapter's responsibility.

Every trial receives a new adapter instance. `Initialize` restores the complete
snapshot, parameter set, and scan interval. `Step(null, false)` advances a
nominal scan; `Step(procedureId, true)` asserts the selected recovery entry
point once and advances a scan; subsequent `Step(procedureId, false)` calls
continue the recovery. The adapter must preserve the configured guards and
protections, advance controller and plant together, return a complete state,
and release owned handles in `Dispose`. The adapter runs as trusted managed
application code in-process, so use adapters you built or reviewed. A
simulator call should return promptly so cancellation can take effect.

## LLM configuration

With no `llm` object or with `"mode":"off"`, the engine evaluates every
eligible supplied or generated hypothesis. Use `"mode":"fixture"` with
`"fixture":"llm-fixture.json"` for a reproducible offline run with selected IDs.

For a provider exposing the chat completions request/response format,
configure the full endpoint, model, secret environment variable, and timeout.
For example, configure a loopback deployment by substituting its actual URL
and model identifier:

```json
{
  "mode": "chatCompletions",
  "endpoint": "http://127.0.0.1:8080/v1/chat/completions",
  "model": "your-local-model",
  "timeoutSeconds": 60
}
```

For authenticated endpoints also set `apiKeyEnvironment` to the environment
variable name holding the bearer token. The desktop application inherits the
environment from its launcher. API keys are never read from the project JSON
or written to reports. The app sends normalized candidate descriptions and
snapshots during boundary selection, sampled trace evidence during diagnosis,
and variant descriptions and supported diagnoses during mitigation selection.
Use a provider appropriate for the sensitivity of those inputs. The expected
assistant message is a JSON object with `candidateIds`, `interventionIds`,
and `variantIds` arrays. The app accepts only eligible IDs and independently
executes each selection. An invalid response or provider failure ends that run
with an actionable error. Set the mode to `off` for an exhaustive local run.

## Prior evidence

Each record in the evidence array includes `id`, baseline `candidate`, optional
`variant`, `scenario`, `source`, `protectionsEnabled`,
`externalInputEndedSeconds`, and `frames`. Each frame contains `seconds`,
`state`, and `recoveryActive`. Export from a prior offline evaluation and use
the same scenario ID for a corresponding variant recording. Include the
pre-recovery state, the actual cessation time, and recovery onset.

The review checks the full state against the validated baseline failure
snapshot and declared context. It reports observed events and timing. For
analogue trajectories, exact full-state matching is intentionally conservative.
A missed sample, differing state, or mismatched provenance should not be
interpreted as proof that a boundary is unreachable. The app does not certify
that prior commands were admissible, authenticate traces, or infer unobserved
attacks. Keep operational and protection model provenance alongside evidence.
