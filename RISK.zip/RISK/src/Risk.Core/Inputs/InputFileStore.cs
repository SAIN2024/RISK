using System.Security.Cryptography;
using System.Text.Json;

namespace Risk.Core;

internal sealed class InputFileStore(string directory)
{
    private readonly Dictionary<string, byte[]> contents = new(
        OperatingSystem.IsWindows() ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal);
    private readonly Dictionary<string, string> hashes = new(StringComparer.Ordinal);

    internal IReadOnlyDictionary<string, string> Hashes => hashes;

    internal T Read<T>(string name) where T : class
    {
        try
        {
            return JsonSerializer.Deserialize<T>(ReadBytes(name), AuditInput.Json) ??
                throw new AuditInputException($"'{name}' must contain a JSON {typeof(T).Name} value.");
        }
        catch (JsonException ex)
        {
            throw new AuditInputException($"Invalid JSON in '{name}' at {ex.Path ?? "$"}: {ex.Message}");
        }
    }

    internal byte[] ReadBytes(string path)
    {
        AuditInput.Require(!string.IsNullOrWhiteSpace(path) && !Path.IsPathRooted(path), "Input paths must be relative.");
        var absolute = Path.GetFullPath(path, directory);
        var relative = Path.GetRelativePath(directory, absolute);
        AuditInput.Require(relative != ".." &&
            !relative.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal) &&
            !Path.IsPathRooted(relative), $"Input path '{path}' leaves the project directory.");

        if (contents.TryGetValue(relative, out var cached)) return cached;
        byte[] bytes;
        try
        {
            bytes = File.ReadAllBytes(absolute);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            throw new AuditInputException($"Cannot read input '{path}': {ex.Message}");
        }

        contents.Add(relative, bytes);
        hashes.Add(relative.Replace('\\', '/'), Convert.ToHexString(SHA256.HashData(bytes)));
        return bytes;
    }
}
