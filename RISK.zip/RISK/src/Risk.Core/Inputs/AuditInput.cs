using System.Text.Json;
using System.Text.Json.Serialization;

namespace Risk.Core;

public sealed class AuditInput
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true,
        AllowDuplicateProperties = false,
        UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow,
        PropertyNameCaseInsensitive = false
    };

    public ProjectSpec Project { get; }
    public ModelSpec Baseline { get; }
    public IReadOnlyDictionary<string, ModelSpec> Models { get; }
    public IReadOnlyDictionary<string, string> Hashes => files.Hashes;
    public IReadOnlyDictionary<string, string[]> Artifacts { get; }
    public EvidenceCase[] Evidence { get; }

    private readonly InputFileStore files;

    public AuditInput(string path)
    {
        path = Path.GetFullPath(path);
        files = new InputFileStore(Path.GetDirectoryName(path)!);
        Project = Read<ProjectSpec>(Path.GetFileName(path));
        Require(!string.IsNullOrWhiteSpace(Project.Name), "Project name is required.");
        Need(Project.Artifacts, "artifacts");
        Need(Project.Procedures, "procedures");
        Need(Project.Snapshots, "snapshots");
        Need(Project.Candidates, "candidates");
        Need(Project.Interventions, "interventions");
        Need(Project.Variants, "variants");
        Need(Project.NominalCases, "nominalCases");
        Artifacts = Project.Artifacts.ToDictionary(a => a.Key, a =>
        {
            using var reader = new StreamReader(new MemoryStream(files.ReadBytes(a.Value)));
            return reader.ReadToEnd().Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        }, StringComparer.Ordinal);
        Baseline = ModelReader.Load(files, Project.Model);
        Unique(Project.Procedures, p => p.Id, "procedure");
        Unique(Project.Snapshots, s => s.Id, "snapshot");
        Unique(Project.Interventions, i => i.Id, "intervention");
        Unique(Project.Variants, v => v.Id, "variant");
        Unique(Project.NominalCases, n => n.Id, "nominal case");

        Models = Project.Variants.ToDictionary(v => v.Id, v => ModelReader.Load(files, v.Model), StringComparer.Ordinal);
        foreach (var variant in Project.Variants)
        {
            ValidateSource(variant.Source);
            Require(Baseline.Variables.ToHashSet().SetEquals(Models[variant.Id].Variables),
                $"Variant '{variant.Id}' must preserve the baseline state interface.");
            if (variant.TriggerOverrides is null) continue;
            foreach (var (procedure, trigger) in variant.TriggerOverrides)
            {
                Find(Project.Procedures, p => p.Id, procedure, "procedure");
                ValidateTests(trigger, Baseline, true);
            }
        }

        foreach (var p in Project.Procedures)
        {
            Need(p.Sources, $"procedure {p.Id} sources");
            ValidateTests(p.Hazard, Baseline);
            ValidateTests(p.Trigger, Baseline, true);
            if (p.Sources.Length == 0) continue;
            ValidateTests(p.Completion, Baseline);
            Require(!string.IsNullOrWhiteSpace(p.Objective), $"Procedure '{p.Id}' requires an objective.");
            Require(p.HorizonSteps is > 0 and <= 100_000 && (p.DeadlineSteps is null or > 0),
                $"Procedure '{p.Id}' has invalid horizon or deadline.");
            foreach (var model in Models.Values.Prepend(Baseline))
            {
                Variable(p.DoneVariable, model);
                if (p.ExhaustedVariable is not null) Variable(p.ExhaustedVariable, model);
                Require(model.Adapter is not null || model.RecoveryRules.ContainsKey(p.Id),
                    $"No simulator rules for procedure '{p.Id}'.");
            }
        }

        foreach (var s in Project.Snapshots)
        {
            ValidateState(s.State, Baseline);
            ValidateSource(s.Source);
        }

        Project = Project with { Candidates = Project.Candidates.Concat(CandidateScan.Generate(Project, Baseline)).ToArray() };
        Unique(Project.Candidates, c => c.Id, "candidate");
        foreach (var c in Project.Candidates)
        {
            Find(Project.Procedures, p => p.Id, c.Procedure, "procedure");
            var safe = Find(Project.Snapshots, s => s.Id, c.SafeSnapshot, "snapshot");
            var fail = Find(Project.Snapshots, s => s.Id, c.FailedSnapshot, "snapshot");
            Variable(c.Coordinate, Baseline);
            ValidateTests(c.Context, Baseline, true);
            Require(safe.State[c.Coordinate] != fail.State[c.Coordinate] &&
                Predicates.Holds(c.Context, safe.State) && Predicates.Holds(c.Context, fail.State),
                $"Candidate '{c.Id}' needs distinct coordinates and snapshots that satisfy its context.");
        }

        foreach (var i in Project.Interventions)
        {
            Find(Project.Candidates, c => c.Id, i.Candidate, "candidate");
            Require(i.Parameter is not null && Baseline.Parameters.TryGetValue(i.Parameter, out var value) &&
                double.IsFinite(i.Value) && value != i.Value, $"Invalid parameter change in '{i.Id}'.");
            Require(!string.IsNullOrWhiteSpace(i.Explanation), $"Intervention '{i.Id}' requires an explanation.");
            ValidateSource(i.Source);
        }

        foreach (var n in Project.NominalCases)
        {
            Find(Project.Procedures, p => p.Id, n.Procedure, "procedure");
            Find(Project.Snapshots, s => s.Id, n.Snapshot, "snapshot");
            Require(n.Steps is > 0 and <= 100_000, $"Invalid horizon in '{n.Id}'.");
            ValidateTests(n.Expected, Baseline);
        }

        Evidence = Project.Evidence is null ? [] : Read<EvidenceCase[]>(Project.Evidence);
        Unique(Evidence, e => e.Id, "evidence case");
        foreach (var e in Evidence)
        {
            Find(Project.Candidates, c => c.Id, e.Candidate, "candidate");
            if (e.Variant is not null) Find(Project.Variants, v => v.Id, e.Variant, "variant");
            ValidateSource(e.Source);
            Need(e.Frames, $"evidence {e.Id} frames");
            Require(!string.IsNullOrWhiteSpace(e.Scenario) && double.IsFinite(e.ExternalInputEndedSeconds) &&
                e.Frames.Length >= 2, $"Evidence '{e.Id}' needs a scenario, cessation time, and at least two frames.");
            var previous = -1.0;
            foreach (var frame in e.Frames)
            {
                Require(double.IsFinite(frame.Seconds) && frame.Seconds >= 0 && frame.Seconds > previous,
                    $"Evidence '{e.Id}' needs strictly increasing nonnegative timestamps.");
                ValidateState(frame.State, Baseline);
                previous = frame.Seconds;
            }
            Require(e.ExternalInputEndedSeconds >= e.Frames[0].Seconds &&
                e.ExternalInputEndedSeconds <= e.Frames[^1].Seconds, $"Cessation is outside evidence '{e.Id}'.");
        }

        if (Project.Llm is { } llm)
        {
            Require(llm.Mode is "off" or "fixture" or "chatCompletions", "Unknown LLM mode.");
            if (llm.Mode == "fixture") _ = Read<LlmResponse>(llm.Fixture!);
            if (llm.Mode == "chatCompletions") _ = ChatCompletionsClient.ValidateSettings(llm);
        }
    }

    public T Read<T>(string name) where T : class => files.Read<T>(name);

    internal static void ValidateState(Dictionary<string, double> state, ModelSpec model)
    {
        Need(state, "state");
        Require(state.Count == model.Variables.Length &&
            model.Variables.All(v => state.TryGetValue(v, out var value) && double.IsFinite(value)),
            "State must contain exactly the simulator variables, with finite values.");
    }

    internal static void ValidateTests(Test[] tests, ModelSpec model, bool allowEmpty = false)
    {
        Need(tests, "conditions");
        Require(allowEmpty || tests.Length > 0, "Predicate must contain at least one condition.");
        foreach (var t in tests)
        {
            Variable(t.Variable, model);
            Require(t.Op is "lt" or "le" or "eq" or "ne" or "ge" or "gt" && double.IsFinite(t.Value),
                "A predicate requires a supported comparison and a finite number.");
        }
    }

    public bool HasGrounding(Procedure p) => p.Sources.Length > 0 && p.Sources.All(MatchesSource);

    private bool MatchesSource(SourceRef? s) => s is not null && !string.IsNullOrWhiteSpace(s.Artifact) &&
        Artifacts.TryGetValue(s.Artifact, out var lines) && s.Line > 0 && s.Line <= lines.Length &&
        !string.IsNullOrWhiteSpace(s.Quote) && lines[s.Line - 1].Contains(s.Quote, StringComparison.Ordinal);

    private void ValidateSource(SourceRef s) => Require(MatchesSource(s),
        $"Evidence quote could not be matched at {s?.Artifact}:{s?.Line}.");

    internal byte[] AdapterBytes(string path) => files.ReadBytes(path);

    internal static void Require(bool condition, string message)
    {
        if (!condition) throw new AuditInputException(message);
    }

    internal static T Need<T>(T? value, string name) where T : class =>
        value ?? throw new AuditInputException($"Missing '{name}'.");

    internal static void Unique<T>(IEnumerable<T> items, Func<T, string> key, string label)
    {
        var keys = new HashSet<string>(StringComparer.Ordinal);
        foreach (var item in items)
        {
            Require(item is not null, $"Null {label}.");
            var id = key(item!);
            Require(!string.IsNullOrWhiteSpace(id) && keys.Add(id), $"Missing or duplicate {label} ID '{id}'.");
        }
    }

    internal static T Find<T>(IEnumerable<T> items, Func<T, string> key, string id, string label) where T : class =>
        items.FirstOrDefault(item => key(item) == id) ?? throw new AuditInputException($"Unknown {label} '{id}'.");

    internal static void Variable(string name, ModelSpec model) =>
        Require(model.Variables.Contains(name, StringComparer.Ordinal), $"Unknown simulator variable '{name}'.");
}
