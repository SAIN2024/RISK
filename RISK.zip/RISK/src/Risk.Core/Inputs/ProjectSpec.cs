namespace Risk.Core;

public sealed record ProjectSpec(
    string Name, string Model, Dictionary<string, string> Artifacts,
    Procedure[] Procedures, Snapshot[] Snapshots, Candidate[] Candidates,
    Intervention[] Interventions, Variant[] Variants, NominalCase[] NominalCases,
    string? Evidence, LlmSettings? Llm, Scan[]? Scans);
public sealed record Scan(string Id, string Procedure, string Coordinate,
    string[] Snapshots, Test[] Context, bool FailureAtHigherValue);
public sealed record SourceRef(string Artifact, int Line, string Quote);
public sealed record Test(string Variable, string Op, double Value);
public sealed record Procedure(string Id, string Objective, SourceRef[] Sources,
    Test[] Hazard, Test[] Trigger, Test[] Completion, string DoneVariable,
    string? ExhaustedVariable, int HorizonSteps, int? DeadlineSteps);
public sealed record Snapshot(string Id, Dictionary<string, double> State, SourceRef Source);
public sealed record Candidate(string Id, string Procedure, string Coordinate,
    string SafeSnapshot, string FailedSnapshot, Test[] Context);
public sealed record Intervention(string Id, string Candidate, string Parameter, double Value,
    string Explanation, SourceRef Source);
public sealed record Variant(string Id, string Description, string Model, SourceRef Source,
    Dictionary<string, Test[]>? TriggerOverrides);
public sealed record NominalCase(string Id, string Procedure, string Snapshot, int Steps, Test[] Expected);
public sealed record LlmSettings(string Mode, string? Fixture, string? Endpoint, string? Model,
    string? ApiKeyEnvironment, int TimeoutSeconds);
