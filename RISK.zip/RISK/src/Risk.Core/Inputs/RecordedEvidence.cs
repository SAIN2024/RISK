namespace Risk.Core;

public sealed record EvidenceCase(string Id, string Candidate, string? Variant, string Scenario,
    SourceRef Source, bool ProtectionsEnabled, double ExternalInputEndedSeconds, EvidenceFrame[] Frames);
public sealed record EvidenceFrame(double Seconds, Dictionary<string, double> State, bool RecoveryActive);
