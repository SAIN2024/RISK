namespace Risk.Core;

public sealed record ModelSpec(double StepSeconds, Dictionary<string, double> Parameters,
    string[] Variables, Rule[] NominalRules, Dictionary<string, Rule[]> RecoveryRules, Rate[] Rates,
    SimulatorBinding? Adapter);
public sealed record SimulatorBinding(string Assembly, string Type);
public sealed record Rule(Test[] When, Dictionary<string, double> Set);
public sealed record Rate(string Variable, double Constant, Dictionary<string, double> StateTerms,
    Dictionary<string, double> ParameterTerms);
