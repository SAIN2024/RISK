namespace Risk.Core;

public sealed class AuditInputException(string message) : Exception(message);
