using static Risk.Core.AuditInput;

namespace Risk.Core;

internal static class ModelReader
{
    internal static ModelSpec Load(InputFileStore files, string name)
    {
        var model = files.Read<ModelSpec>(name);
        Require(double.IsFinite(model.StepSeconds) && model.StepSeconds > 0, "Invalid simulator step.");
        Need(model.Variables, "simulator variables");
        Need(model.Parameters, "simulator parameters");
        Need(model.NominalRules, "nominal rules");
        Need(model.RecoveryRules, "recovery rules");
        Need(model.Rates, "simulator rates");
        Unique(model.Variables, v => v, "simulator variable");
        Require(model.Variables.Length > 0 && model.Parameters.Values.All(double.IsFinite),
            "Model requires variables and finite parameters.");
        if (model.Adapter is not null)
        {
            var bytes = files.ReadBytes(model.Adapter.Assembly);
            Require(bytes.Length > 0 && !string.IsNullOrWhiteSpace(model.Adapter.Type),
                "Simulator adapter requires a DLL and fully qualified type.");
            Require(model.NominalRules.Length == 0 && model.Rates.Length == 0 && model.RecoveryRules.Count == 0,
                "An adapter model supplies its logic through the DLL.");
        }
        foreach (var rules in model.RecoveryRules.Values.Append(model.NominalRules))
        {
            foreach (var rule in Need(rules, "simulator rule set"))
            {
                ValidateTests(rule.When, model, true);
                foreach (var (variable, value) in Need(rule.Set, "rule assignments"))
                {
                    Variable(variable, model);
                    Require(double.IsFinite(value), $"Rule writes a non-finite value to '{variable}'.");
                }
            }
        }

        Unique(model.Rates, rate => rate.Variable, "derivative");
        foreach (var rate in model.Rates)
        {
            Variable(rate.Variable, model);
            Require(double.IsFinite(rate.Constant), "Derivative constant must be finite.");
            foreach (var (variable, factor) in Need(rate.StateTerms, "state terms"))
            {
                Variable(variable, model);
                Require(double.IsFinite(factor), "Derivative coefficient must be finite.");
            }
            foreach (var (parameter, factor) in Need(rate.ParameterTerms, "parameter terms"))
                Require(model.Parameters.ContainsKey(parameter) && double.IsFinite(factor),
                    $"Invalid derivative parameter '{parameter}'.");
        }
        return model;
    }
}
