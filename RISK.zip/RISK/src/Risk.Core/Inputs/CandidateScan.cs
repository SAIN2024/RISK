using System.Globalization;
using static Risk.Core.AuditInput;

namespace Risk.Core;

internal static class CandidateScan
{
    internal static IEnumerable<Candidate> Generate(ProjectSpec project, ModelSpec baseline)
    {
        var scans = project.Scans ?? [];
        Unique(scans, scan => scan.Id, "scan");
        foreach (var scan in scans)
        {
            Find(project.Procedures, p => p.Id, scan.Procedure, "procedure");
            Variable(scan.Coordinate, baseline);
            ValidateTests(scan.Context, baseline, true);
            Need(scan.Snapshots, "scan snapshot IDs");
            Require(scan.Snapshots.Length is >= 2 and <= 1000, $"Scan '{scan.Id}' needs 2 to 1,000 snapshots.");
            Unique(scan.Snapshots, id => id, "scan snapshot ID");
            var snapshots = scan.Snapshots
                .Select(id => Find(project.Snapshots, s => s.Id, id, "snapshot"))
                .Where(s => Predicates.Holds(scan.Context, s.State));
            var otherVariables = baseline.Variables.Where(v => v != scan.Coordinate).ToArray();
            var groups = snapshots.GroupBy(s => string.Join("|", otherVariables
                .Select(v => s.State[v].ToString("R", CultureInfo.InvariantCulture))));
            var count = 0;
            foreach (var group in groups)
            {
                var sorted = group.OrderBy(s => s.State[scan.Coordinate])
                    .DistinctBy(s => s.State[scan.Coordinate]).ToArray();
                for (var i = 1; i < sorted.Length; i++)
                {
                    var safe = scan.FailureAtHigherValue ? sorted[i - 1] : sorted[i];
                    var failed = scan.FailureAtHigherValue ? sorted[i] : sorted[i - 1];
                    yield return new Candidate($"{scan.Id}/{safe.Id}/{failed.Id}", scan.Procedure,
                        scan.Coordinate, safe.Id, failed.Id, scan.Context);
                    count++;
                }
            }
            Require(count > 0, $"Scan '{scan.Id}' found no comparable snapshot pairs.");
        }
    }
}
