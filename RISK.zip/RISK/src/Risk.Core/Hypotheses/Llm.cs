namespace Risk.Core;

public sealed record LlmResponse(string[] CandidateIds, string[] InterventionIds, string[] VariantIds);

internal sealed class Llm(AuditInput input)
{
    public async Task<string[]> Select(string stage, string[] available, object evidence, CancellationToken token)
    {
        if (available.Length == 0) return [];
        var settings = input.Project.Llm;
        if (settings is null || settings.Mode == "off") return available;
        LlmResponse response;
        if (settings.Mode == "fixture")
        {
            response = input.Read<LlmResponse>(settings.Fixture!);
        }
        else if (settings.Mode == "chatCompletions")
            response = await ChatCompletionsClient.SelectAsync(settings, stage, available, evidence, token)
                .ConfigureAwait(false);
        else throw new AuditInputException($"Unknown LLM mode '{settings.Mode}'.");

        var selected = stage switch
        {
            "boundaries" => response.CandidateIds,
            "diagnosis" => response.InterventionIds,
            "mitigation" => response.VariantIds,
            _ => throw new InvalidOperationException($"Unknown stage {stage}.")
        };
        AuditInput.Need(selected, $"{stage} IDs");
        if (settings.Mode != "fixture" && selected.Any(id => !available.Contains(id, StringComparer.Ordinal)))
            throw new AuditInputException($"LLM stage '{stage}' returned an ineligible ID.");
        return selected.Where(id => available.Contains(id, StringComparer.Ordinal)).Distinct().ToArray();
    }
}
