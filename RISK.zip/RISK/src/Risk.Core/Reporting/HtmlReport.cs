using System.Globalization;
using System.Net;
using System.Text;

namespace Risk.Core;

internal static class HtmlReport
{
    internal static string Render(AuditReport report)
    {
        var html = new StringBuilder("""
            <!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
            <title>RISK recovery audit</title>
            <style>body{font:16px/1.55 system-ui;margin:3rem auto;max-width:70rem;padding:0 1.25rem;color:#10252b;background:#f7faf9}
            h1{font-size:2.4rem;line-height:1.1}h2{margin-top:2.4rem}table{border-collapse:collapse;width:100%;background:white}
            th,td{padding:.65rem .8rem;text-align:left;border-bottom:1px solid #d6e1df}th{background:#e5efed}
            a{color:#15534b}caption{text-align:left;font-weight:600;margin:.8rem 0}small{color:#48605e}</style><main>
            """);
        html.Append("<h1>").Append(E(report.Name)).Append("</h1><p><small>")
            .Append(E(report.CompletedUtc.ToString("u", CultureInfo.InvariantCulture)))
            .Append(" · RISK ").Append(E(report.ArtifactVersion))
            .Append(" · LLM mode: ").Append(E(report.LlmMode))
            .Append("</small></p><p><a href=\"report.json\">Full report (JSON)</a> · <a href=\"trajectories.csv\">Simulation traces (CSV)</a></p>");
        Table("Artifact grounding", ["Procedure", "Result"],
            report.Coverage.Select(c => new[] { c.Procedure, c.Status }));
        Table("Audit coverage", ["Stage", "Eligible hypotheses", "Evaluated hypotheses"],
            report.Selections.Select(s => new[] { s.Stage, s.EligibleIds.Length.ToString(CultureInfo.InvariantCulture),
                s.EvaluatedIds.Length.ToString(CultureInfo.InvariantCulture) }));
        Table("Recovery boundaries", ["Candidate", "Witness coordinates", "Result", "Failure witness initially hazardous"], BoundaryRows(report.Boundaries));
        Table("Recorded evidence", ["Scenario", "Candidate", "Result", "Source"],
            EvidenceRows(report.RecordedEvidence));
        Table("Counterfactual diagnosis", ["Intervention", "Hypothesis", "Parameter", "Result"],
            report.Diagnoses.Select(d => new[] { d.Id, d.Explanation,
                $"{d.Parameter}: {F(d.BaselineValue)} → {F(d.CounterfactualValue)}", d.Status }));
        Table("Baseline nominal operation", ["Test", "Result"],
            report.NominalBaseline.Select(n => new[] { n.Id, n.Result.Outcome }));
        html.Append("<h2>Mitigation re-audit</h2>");
        if (report.Mitigations.Length == 0) html.Append("<p>No mitigation variants evaluated.</p>");
        foreach (var m in report.Mitigations)
        {
            html.Append("<h3>").Append(E(m.Id)).Append("</h3><p>").Append(E(m.Description)).Append("</p>");
            if (m.TriggerOverrides.Length > 0)
                html.Append("<p>Modified recovery triggers: ").Append(E(string.Join(", ", m.TriggerOverrides))).Append("</p>");
            Table("Recovery re-audit", ["Candidate", "Witness coordinates", "Result", "Failure witness initially hazardous"], BoundaryRows(m.ReauditedBoundaries));
            Table("Nominal comparison", ["Test", "Baseline", "Modified", "Compatibility"],
                m.Nominal.Select(n => new[] { n.Id, n.Baseline, n.Result.Outcome, n.Comparison }));
            Table("Recorded variant evidence", ["Scenario", "Candidate", "Result", "Source"],
                EvidenceRows(m.RecordedEvidence));
        }
        html.Append("<p><small>Boundaries are local to tested states and model behavior. Imported recordings are evidence supplied by the operator. The audit does not infer untested reachability or verify the recording provenance independently.</small></p></main></html>");
        return html.ToString();

        static string E(string value) => WebUtility.HtmlEncode(value);
        static string F(double value) => value.ToString("G8", CultureInfo.InvariantCulture);
        static IEnumerable<string[]> BoundaryRows(IEnumerable<Boundary> boundaries) =>
            boundaries.Select(b => new[] { b.Id, $"{b.Coordinate}: {F(b.SafeCoordinate)} / {F(b.FailedCoordinate)}", b.Status, b.FailureWitnessAlreadyHazardous ? "Yes" : "No" });
        static IEnumerable<string[]> EvidenceRows(IEnumerable<EvidenceResult> evidence) =>
            evidence.Select(e => new[] { e.Scenario, e.Candidate, e.Status, $"{e.Source.Artifact}:{e.Source.Line}" });

        void Table(string heading, string[] headers, IEnumerable<string[]> rows)
        {
            var data = rows.ToArray();
            html.Append("<table><caption>").Append(E(heading)).Append("</caption><thead><tr>");
            foreach (var header in headers) html.Append("<th scope=\"col\">").Append(E(header)).Append("</th>");
            html.Append("</tr></thead><tbody>");
            if (data.Length == 0) html.Append("<tr><td colspan=\"").Append(headers.Length).Append("\">No results.</td></tr>");
            foreach (var row in data)
            {
                html.Append("<tr>");
                foreach (var cell in row) html.Append("<td>").Append(E(cell)).Append("</td>");
                html.Append("</tr>");
            }
            html.Append("</tbody></table>");
        }
    }
}
