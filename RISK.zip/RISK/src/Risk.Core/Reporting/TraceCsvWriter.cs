using System.Globalization;

namespace Risk.Core;

internal static class TraceCsvWriter
{
    internal static async Task WriteAsync(AuditReport report, string path, CancellationToken token)
    {
        await using var writer = new StreamWriter(path);
        writer.NewLine = "\r\n";
        await writer.WriteLineAsync(
            "phase,variant,case,witness,outcome,seconds,recovery_active,variable,value".AsMemory(), token)
            .ConfigureAwait(false);
        foreach (var entry in Trials(report))
        {
            var prefix = string.Join(",", Text(entry.Phase), Text(entry.Variant), Text(entry.Id),
                Text(entry.Witness), Text(entry.Trial.Outcome));
            foreach (var frame in entry.Trial.Frames)
            {
                token.ThrowIfCancellationRequested();
                var framePrefix = $"{prefix},{Number(frame.Seconds)},{(frame.RecoveryActive ? "true" : "false")}";
                foreach (var (variable, value) in frame.State)
                    await writer.WriteLineAsync($"{framePrefix},{Text(variable)},{Number(value)}".AsMemory(), token)
                        .ConfigureAwait(false);
            }
        }
    }

    private static IEnumerable<Entry> Trials(AuditReport report)
    {
        foreach (var trial in Boundaries(report.Boundaries, "")) yield return trial;
        foreach (var diagnosis in report.Diagnoses)
            yield return new Entry("counterfactual", "", diagnosis.Id, "failed", diagnosis.Replay);
        foreach (var nominal in report.NominalBaseline)
            yield return new Entry("nominal", "", nominal.Id, "", nominal.Result);
        foreach (var mitigation in report.Mitigations)
        {
            foreach (var trial in Boundaries(mitigation.ReauditedBoundaries, mitigation.Id)) yield return trial;
            foreach (var nominal in mitigation.Nominal)
                yield return new Entry("nominal", mitigation.Id, nominal.Id, "", nominal.Result);
        }
    }

    private static IEnumerable<Entry> Boundaries(IEnumerable<Boundary> boundaries, string variant)
    {
        foreach (var boundary in boundaries)
        {
            yield return new Entry("boundary", variant, boundary.Id, "safe", boundary.SafeTrial);
            yield return new Entry("boundary", variant, boundary.Id, "failed", boundary.FailedTrial);
        }
    }

    private static string Number(double value) => value.ToString("R", CultureInfo.InvariantCulture);

    private static string Text(string value)
    {
        var trimmed = value.AsSpan().TrimStart();
        // Prevent spreadsheet software from interpreting project-supplied labels as formulas.
        if ((!trimmed.IsEmpty && trimmed[0] is '=' or '+' or '-' or '@') ||
            (value.Length > 0 && value[0] is '\t' or '\r' or '\n'))
            value = "'" + value;
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }

    private sealed record Entry(string Phase, string Variant, string Id, string Witness, Trial Trial);
}
