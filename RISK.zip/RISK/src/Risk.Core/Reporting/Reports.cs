using System.Text.Json;

namespace Risk.Core;

public sealed record AuditFiles(string ReportJson, string SummaryHtml)
{
    public string TraceCsv => Path.Combine(Path.GetDirectoryName(ReportJson)!, "trajectories.csv");
}

public static class Reports
{
    public static async Task<AuditFiles> WriteAsync(AuditReport report, string destination,
        CancellationToken token = default)
    {
        Directory.CreateDirectory(destination);
        var final = Path.Combine(destination, $"risk-{DateTime.UtcNow:yyyyMMdd-HHmmss}-{Guid.NewGuid():N}");
        var temporary = final + ".tmp";
        Directory.CreateDirectory(temporary);
        try
        {
            var jsonPath = Path.Combine(temporary, "report.json");
            await using (var stream = File.Create(jsonPath))
                await JsonSerializer.SerializeAsync(stream, report, AuditInput.Json, token).ConfigureAwait(false);
            await File.WriteAllTextAsync(Path.Combine(temporary, "summary.html"), HtmlReport.Render(report), token)
                .ConfigureAwait(false);
            await TraceCsvWriter.WriteAsync(report, Path.Combine(temporary, "trajectories.csv"), token)
                .ConfigureAwait(false);
            token.ThrowIfCancellationRequested();
            Directory.Move(temporary, final);
            return new AuditFiles(Path.Combine(final, "report.json"), Path.Combine(final, "summary.html"));
        }
        finally
        {
            if (Directory.Exists(temporary)) Directory.Delete(temporary, recursive: true);
        }
    }

}
