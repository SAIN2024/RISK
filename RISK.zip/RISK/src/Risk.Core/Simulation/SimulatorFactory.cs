using System.Runtime.Loader;

namespace Risk.Core;

internal static class SimulatorFactory
{
    internal static IOfflineSimulator Create(AuditInput input, ModelSpec model)
    {
        if (model.Adapter is not { } adapter) return new DeclarativeSimulator(model);
        var bytes = input.AdapterBytes(adapter.Assembly);
        var hash = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes));
        var assembly = AdapterStore.Load(hash, bytes);
        var type = assembly.GetType(adapter.Type, throwOnError: true)!;
        if (!typeof(IOfflineSimulator).IsAssignableFrom(type) || type.IsAbstract ||
            type.GetConstructor(Type.EmptyTypes) is null)
            throw new AuditInputException($"'{adapter.Type}' must implement IOfflineSimulator and have a public parameterless constructor.");
        return (IOfflineSimulator)Activator.CreateInstance(type)!;
    }

    private static class AdapterStore
    {
        private static readonly Dictionary<string, System.Reflection.Assembly> Assemblies = new();

        internal static System.Reflection.Assembly Load(string hash, byte[] bytes)
        {
            lock (Assemblies)
            {
                if (Assemblies.TryGetValue(hash, out var assembly)) return assembly;
                var context = new AssemblyLoadContext($"RISK simulator {hash}");
                using var stream = new MemoryStream(bytes);
                assembly = context.LoadFromStream(stream);
                Assemblies.Add(hash, assembly);
                return assembly;
            }
        }
    }

}
