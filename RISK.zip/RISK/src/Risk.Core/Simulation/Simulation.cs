namespace Risk.Core;

public static class Simulation
{
    internal static Trial Run(AuditInput input, ModelSpec model, Procedure p, Snapshot snapshot,
        NominalCase? nominal, CancellationToken token)
    {
        var frames = new List<EvidenceFrame>();
        var state = new Dictionary<string, double>(snapshot.State);
        using var simulator = SimulatorFactory.Create(input, model);
        simulator.Initialize(new Dictionary<string, double>(state), new Dictionary<string, double>(model.Parameters),
            model.StepSeconds);

        int? started = nominal is null ? 0 : null;
        bool recoveryCompleted = false;
        var horizon = nominal?.Steps ?? p.HorizonSteps;
        for (var step = 0; step <= horizon; step++)
        {
            token.ThrowIfCancellationRequested();
            if (!recoveryCompleted && started is null && p.Trigger.Length > 0 && Predicates.Holds(p.Trigger, state))
                started = step;

            var active = started is not null && !recoveryCompleted;
            var startsNow = active && started == step;
            var seconds = step * model.StepSeconds;
            if (!double.IsFinite(seconds))
                throw new AuditInputException("Simulator time exceeds the numeric range.");
            frames.Add(new EvidenceFrame(seconds, new(state), active));

            if (Predicates.Holds(p.Hazard, state)) return End("Failed", "Hazard observed.");
            if (active && !startsNow)
            {
                var done = Predicates.Flag(state, p.DoneVariable);
                if (done && Predicates.Holds(p.Completion, state))
                {
                    if (nominal is null) return End("Recovered", "Physical completion observed before hazard.");
                    recoveryCompleted = true;
                    active = false;
                }
                else if (done || Predicates.Flag(state, p.ExhaustedVariable))
                    return End("Failed", done ? "Procedure ended without physical completion." : "Recovery exhausted.");
                else if (p.DeadlineSteps is int deadline && step - started >= deadline)
                    return End("Failed", "Deployed completion deadline expired.");
            }

            if (step == horizon)
            {
                if (active || nominal is null) return End("Unresolved", "Observation horizon ended during recovery.");
                return Predicates.Holds(nominal.Expected, state)
                    ? End("Passed", "Nominal checks passed throughout the observed run and at its endpoint.")
                    : End("Failed", "Nominal endpoint expectation failed.");
            }

            state = simulator.Step(active ? p.Id : null, startsNow);
            AuditInput.ValidateState(state, model);
        }
        throw new InvalidOperationException("Invalid run horizon.");

        Trial End(string outcome, string reason) => new(outcome, reason, frames);
    }

}

public sealed record Trial(string Outcome, string Reason, List<EvidenceFrame> Frames);
