namespace Risk.Core;

internal sealed class DeclarativeSimulator(ModelSpec model) : IOfflineSimulator
{
    private Dictionary<string, double> state = new();

    public void Initialize(IReadOnlyDictionary<string, double> initial,
        IReadOnlyDictionary<string, double> parameters, double stepSeconds) => state = new(initial);

    public Dictionary<string, double> Step(string? procedure, bool startsRecovery)
    {
        var rules = procedure is null ? model.NominalRules : model.RecoveryRules[procedure];
        foreach (var rule in rules)
            if (Predicates.Holds(rule.When, state))
                foreach (var (variable, value) in rule.Set) state[variable] = value;

        var next = new Dictionary<string, double>(state);
        foreach (var rate in model.Rates)
        {
            var derivative = rate.Constant +
                rate.StateTerms.Sum(t => state[t.Key] * t.Value) +
                rate.ParameterTerms.Sum(t => model.Parameters[t.Key] * t.Value);
            next[rate.Variable] += model.StepSeconds * derivative;
        }
        state = next;
        return next;
    }

    public void Dispose() { }
}
