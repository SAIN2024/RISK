namespace Risk.Core;

internal static class Predicates
{
    internal static bool Holds(IEnumerable<Test> tests, IReadOnlyDictionary<string, double> state) =>
        tests.All(t => t.Op switch
        {
            "lt" => state[t.Variable] < t.Value,
            "le" => state[t.Variable] <= t.Value,
            "eq" => state[t.Variable] == t.Value,
            "ne" => state[t.Variable] != t.Value,
            "ge" => state[t.Variable] >= t.Value,
            "gt" => state[t.Variable] > t.Value,
            _ => throw new AuditInputException($"Unknown operator '{t.Op}'.")
        });

    internal static bool Flag(IReadOnlyDictionary<string, double> state, string? key) =>
        key is not null && state[key] != 0;

}
