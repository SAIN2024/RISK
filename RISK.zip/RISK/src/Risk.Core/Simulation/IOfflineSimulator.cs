namespace Risk.Core;

public interface IOfflineSimulator : IDisposable
{
    // Initialize all hidden state from the supplied snapshot and parameters.
    void Initialize(IReadOnlyDictionary<string, double> state,
        IReadOnlyDictionary<string, double> parameters, double stepSeconds);

    // Run one scan. A null procedure requests a normal scan.
    Dictionary<string, double> Step(string? procedure, bool startsRecovery);
}
