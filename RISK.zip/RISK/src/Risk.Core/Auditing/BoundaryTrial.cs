namespace Risk.Core;

internal static class BoundaryTrial
{
    internal static Boundary Run(AuditInput input, Candidate c, Procedure p, Snapshot safe, Snapshot fail,
        ModelSpec model, CancellationToken token)
    {
        var safeTrial = Simulation.Run(input, model, p, safe, null, token);
        var failTrial = Simulation.Run(input, model, p, fail, null, token);
        var status = (safeTrial.Outcome, failTrial.Outcome) switch
        {
            ("Recovered", "Failed") => "Confirmed",
            ("Failed", "Recovered") => "Reversed at tested states",
            ("Unresolved", _) or (_, "Unresolved") => "Unresolved",
            _ => "No transition at tested states"
        };
        return new Boundary(c.Id, c.Procedure, c.Coordinate, safe.State[c.Coordinate], fail.State[c.Coordinate],
            c.Context, model.Variables.Where(v => v != c.Coordinate && safe.State[v] != fail.State[v]).ToArray(),
            status, Predicates.Holds(p.Hazard, fail.State), safe.Id, fail.Id, safe.Source, fail.Source, safeTrial, failTrial);
    }
}
