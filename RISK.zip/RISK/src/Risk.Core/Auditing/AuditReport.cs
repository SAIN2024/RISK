namespace Risk.Core;

public sealed record Coverage(string Procedure, string Status, SourceRef[] Sources);
public sealed record Selection(string Stage, string[] EligibleIds, string[] EvaluatedIds);
public sealed record Boundary(string Id, string Procedure, string Coordinate, double SafeCoordinate,
    double FailedCoordinate, Test[] Context, string[] OtherChangedVariables, string Status, bool FailureWitnessAlreadyHazardous,
    string SafeSnapshot, string FailedSnapshot, SourceRef SafeSource, SourceRef FailedSource,
    Trial SafeTrial, Trial FailedTrial);
public sealed record Diagnosis(string Id, string Candidate, string Explanation, string Parameter,
    double BaselineValue, double CounterfactualValue, string Status, Trial Replay, SourceRef Source);
public sealed record EvidenceResult(string Id, string Candidate, string? Variant, string Scenario,
    string Status, double? EntrySeconds, double? RecoverySeconds, double? HazardSeconds,
    double CessationSeconds, SourceRef Source);
public sealed record Regression(string Id, string Baseline, Trial Result)
{
    public string Comparison => (Baseline, Result.Outcome) switch
    {
        ("Passed", "Failed") => "Regression observed",
        ("Passed", "Unresolved") => "Compatibility unresolved",
        ("Passed", "Passed") => "Preserved",
        (_, "Passed") => "Passed after modification",
        _ => "Baseline did not establish compatibility"
    };
}
public sealed record Mitigation(string Id, string Description, SourceRef Source, bool ModelChanged,
    string[] TriggerOverrides,
    Boundary[] ReauditedBoundaries, Regression[] Nominal, EvidenceResult[] RecordedEvidence);
public sealed record AuditReport(string Name, DateTimeOffset CompletedUtc, string LlmMode, string? LlmModel,
    string ArtifactVersion, IReadOnlyDictionary<string, string> InputSha256,
    Coverage[] Coverage, Selection[] Selections, Boundary[] Boundaries,
    Diagnosis[] Diagnoses, EvidenceResult[] RecordedEvidence, Regression[] NominalBaseline,
    Mitigation[] Mitigations);
