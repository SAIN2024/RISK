namespace Risk.Core;

internal static class RecordedEvidenceReview
{
    internal static EvidenceResult Review(EvidenceCase e, Candidate c, Procedure p, Snapshot failed,
        IReadOnlyList<string> variables, bool confirmed)
    {
        double? entry = null;
        double? start = null;
        double? hazard = null;
        double? completion = null;
        var status = "Unresolved recorded outcome";
        var startedOnWitness = variables.All(
            v => e.Frames[0].State[v] == failed.State[v]);

        if (!confirmed) status = "No confirmed baseline boundary";
        else if (!e.ProtectionsEnabled) status = "Protections not attested";
        else if (e.Frames[0].RecoveryActive) status = "Recovery onset missing from recording";
        else
        {
            foreach (var frame in e.Frames)
            {
                if (!startedOnWitness && entry is null && Predicates.Holds(c.Context, frame.State) &&
                    variables.All(v => frame.State[v] == failed.State[v]))
                    entry = frame.Seconds;
                if (frame.RecoveryActive && start is null) start = frame.Seconds;
                if (Predicates.Holds(p.Hazard, frame.State))
                {
                    hazard = frame.Seconds;
                    break;
                }
                if (start is not null && frame.Seconds > start && frame.RecoveryActive &&
                    Predicates.Flag(frame.State, p.DoneVariable) && Predicates.Holds(p.Completion, frame.State))
                {
                    completion = frame.Seconds;
                    break;
                }
            }

            if (startedOnWitness) status = "Timeline began at the failure witness";
            else if (entry is not null && start is not null && entry <= start &&
                e.ExternalInputEndedSeconds <= start && hazard is not null && hazard >= start &&
                hazard > e.ExternalInputEndedSeconds)
                status = "Recorded witness followed by hazard after cessation";
            else if (entry is not null && hazard is not null && hazard <= e.ExternalInputEndedSeconds)
                status = "Recorded hazard at or before cessation";
            else if (completion is not null)
                status = entry is null ? "Recovered without observed entry" : "Recovered after observed entry";
            else if (entry is null) status = "Failure witness not observed";
        }
        return new EvidenceResult(e.Id, c.Id, e.Variant, e.Scenario, status, entry, start,
            hazard, e.ExternalInputEndedSeconds, e.Source);
    }
}
