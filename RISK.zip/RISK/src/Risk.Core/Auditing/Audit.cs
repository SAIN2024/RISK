using System.Text.Json;

namespace Risk.Core;

public sealed class Audit(AuditInput input)
{
    private ProjectSpec Project => input.Project;

    public async Task<AuditReport> RunAsync(IProgress<string>? progress = null, CancellationToken token = default)
    {
        token.ThrowIfCancellationRequested();
        var llm = new Llm(input);
        var coverage = Project.Procedures.Select(p => new Coverage(p.Id,
            p.Sources.Length == 0 ? "Recovery coverage gap" :
            input.HasGrounding(p) ? "Grounded source references" : "Unresolved source references", p.Sources)).ToArray();
        var grounded = Project.Procedures.Where(input.HasGrounding).Select(p => p.Id).ToHashSet();
        var candidates = Project.Candidates.Where(c => grounded.Contains(c.Procedure)).ToArray();
        progress?.Report("Selecting candidate recovery boundaries.");
        var proposed = await llm.Select("boundaries", candidates.Select(c => c.Id).ToArray(),
            new { candidates, procedures = Project.Procedures.Where(input.HasGrounding), Project.Snapshots },
            token).ConfigureAwait(false);
        var boundaries = proposed.Select(id =>
        {
            progress?.Report($"Testing both sides of {id}.");
            return TestBoundary(Candidate(id), input.Baseline, token);
        }).ToArray();

        progress?.Report("Reviewing previously recorded recovery timelines.");
        var confirmed = boundaries.Where(b => b.Status == "Confirmed").Select(b => b.Id).ToHashSet();
        var observed = input.Evidence.Where(e => e.Variant is null)
            .Select(e => ReviewEvidence(e, confirmed)).ToArray();

        var interventions = Project.Interventions.Where(i => confirmed.Contains(i.Candidate)).ToArray();
        var diagnosticIds = await llm.Select("diagnosis", interventions.Select(i => i.Id).ToArray(),
            new { interventions, boundaries = boundaries.Where(b => confirmed.Contains(b.Id)).Select(Brief) },
            token).ConfigureAwait(false);
        var diagnoses = diagnosticIds.Select(id =>
        {
            progress?.Report($"Testing counterfactual {id}.");
            var intervention = AuditInput.Find(interventions, i => i.Id, id, "intervention");
            var parameters = new Dictionary<string, double>(input.Baseline.Parameters)
                { [intervention.Parameter] = intervention.Value };
            var candidate = Candidate(intervention.Candidate);
            var result = Simulation.Run(input, input.Baseline with { Parameters = parameters },
                Procedure(candidate.Procedure), Snapshot(candidate.FailedSnapshot), null, token);
            return new Diagnosis(id, candidate.Id, intervention.Explanation, intervention.Parameter,
                input.Baseline.Parameters[intervention.Parameter], intervention.Value,
                result.Outcome switch
                {
                    "Recovered" => "Supported in counterfactual",
                    "Failed" => "Counterfactual did not restore recovery",
                    _ => "Unresolved"
                }, result, intervention.Source);
        }).ToArray();

        var nominal = Project.NominalCases.Where(n => grounded.Contains(n.Procedure)).ToArray();
        progress?.Report("Running baseline nominal cases.");
        var baselineNominal = nominal.ToDictionary(n => n.Id, n => RunNominal(n, input.Baseline, token));
        var variants = await llm.Select("mitigation", Project.Variants.Select(v => v.Id).ToArray(),
            new
            {
                variants = Project.Variants,
                diagnoses = diagnoses.Select(d => new { d.Id, d.Candidate, d.Explanation, d.Status }),
                boundaries = boundaries.Select(Brief)
            }, token).ConfigureAwait(false);
        var mitigations = variants.Select(id =>
        {
            progress?.Report($"Re-auditing mitigation {id}.");
            var variant = AuditInput.Find(Project.Variants, v => v.Id, id, "variant");
            var model = input.Models[id];
            return new Mitigation(id, variant.Description, variant.Source, ModelChanged(variant),
                variant.TriggerOverrides?.Keys.ToArray() ?? [],
                proposed.Select(c => TestBoundary(Candidate(c), model, token)).ToArray(),
                nominal.Select(n => new Regression(n.Id, baselineNominal[n.Id].Outcome,
                    RunNominal(n, model, token, variant))).ToArray(),
                input.Evidence.Where(e => e.Variant == id).Select(e => ReviewEvidence(e, confirmed)).ToArray());
        }).ToArray();

        return new AuditReport(Project.Name, DateTimeOffset.UtcNow, Project.Llm?.Mode ?? "off",
            Project.Llm?.Mode == "chatCompletions" ? Project.Llm.Model : null,
            typeof(Audit).Assembly.GetName().Version!.ToString(3), input.Hashes, coverage,
            [
                new("Boundaries", candidates.Select(c => c.Id).ToArray(), proposed),
                new("Diagnosis", interventions.Select(i => i.Id).ToArray(), diagnosticIds),
                new("Mitigation", Project.Variants.Select(v => v.Id).ToArray(), variants)
            ],
            boundaries, diagnoses, observed,
            baselineNominal.Select(kv => new Regression(kv.Key, kv.Value.Outcome, kv.Value)).ToArray(),
            mitigations);
    }

    private Candidate Candidate(string id) => AuditInput.Find(Project.Candidates, c => c.Id, id, "candidate");
    private Procedure Procedure(string id) => AuditInput.Find(Project.Procedures, p => p.Id, id, "procedure");
    private Snapshot Snapshot(string id) => AuditInput.Find(Project.Snapshots, s => s.Id, id, "snapshot");

    private bool ModelChanged(Variant variant)
    {
        var baseline = input.Baseline;
        var modified = input.Models[variant.Id];
        if (baseline.Adapter is { } a && modified.Adapter is { } b &&
            !input.AdapterBytes(a.Assembly).AsSpan().SequenceEqual(input.AdapterBytes(b.Assembly))) return true;
        return !JsonSerializer.SerializeToUtf8Bytes(baseline, AuditInput.Json)
            .AsSpan().SequenceEqual(JsonSerializer.SerializeToUtf8Bytes(modified, AuditInput.Json));
    }

    private Boundary TestBoundary(Candidate candidate, ModelSpec model, CancellationToken token) =>
        BoundaryTrial.Run(input, candidate, Procedure(candidate.Procedure), Snapshot(candidate.SafeSnapshot),
            Snapshot(candidate.FailedSnapshot), model, token);

    private Trial RunNominal(NominalCase n, ModelSpec model, CancellationToken token, Variant? variant = null)
    {
        var p = Procedure(n.Procedure);
        if (variant?.TriggerOverrides?.TryGetValue(p.Id, out var trigger) == true) p = p with { Trigger = trigger };
        return Simulation.Run(input, model, p, Snapshot(n.Snapshot), n, token);
    }

    private EvidenceResult ReviewEvidence(EvidenceCase recording, HashSet<string> confirmed)
    {
        var candidate = Candidate(recording.Candidate);
        return RecordedEvidenceReview.Review(recording, candidate, Procedure(candidate.Procedure),
            Snapshot(candidate.FailedSnapshot), input.Baseline.Variables, confirmed.Contains(candidate.Id));
    }

    private static object Brief(Boundary b) => new
    {
        b.Id, b.Coordinate, b.SafeCoordinate, b.FailedCoordinate, b.Status,
        safe = Compact(b.SafeTrial),
        failed = Compact(b.FailedTrial)
    };

    private static object Compact(Trial t) => new
    {
        t.Outcome, t.Reason,
        frames = t.Frames.Count <= 12 ? t.Frames.ToArray() :
            Enumerable.Range(0, 12).Select(i => t.Frames[(int)(i * (t.Frames.Count - 1L) / 11)]).ToArray()
    };
}
