using System.Diagnostics;
using Risk.Core;

namespace Risk.Desktop;

internal sealed class AuditWindow : Form
{
    private readonly TextBox project = new() { Dock = DockStyle.Fill };
    private readonly TextBox destination = new() { Dock = DockStyle.Fill };
    private readonly TextBox log = new()
    {
        Dock = DockStyle.Fill, Multiline = true, ReadOnly = true,
        ScrollBars = ScrollBars.Vertical, BackColor = Color.White
    };
    private readonly Button run = NewButton("Run audit");
    private readonly Button cancel = NewButton("Cancel audit");
    private readonly Button view = NewButton("View report");
    private readonly Button openFiles = NewButton("Open report folder");
    private readonly Button settings = NewButton("Open project JSON");
    private readonly Button example = NewButton("Use sample project");
    private readonly Button pickProject = NewButton("Browse…");
    private readonly Button pickOutput = NewButton("Browse…");
    private AuditFiles? files;
    private CancellationTokenSource? currentRun;

    public AuditWindow()
    {
        Text = "RISK Recovery Audit";
        MinimumSize = new Size(680, 430);
        ClientSize = new Size(890, 550);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10);
        BackColor = Color.FromArgb(244, 248, 247);
        destination.Text = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "RISK Reports");
        project.AccessibleName = "Audit project JSON";
        destination.AccessibleName = "Report destination";
        log.AccessibleName = "Audit progress and results";

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, Padding = new Padding(22), ColumnCount = 3, RowCount = 6
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 146));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        for (var row = 0; row < 5; row++) layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var title = new Label
        {
            Text = "RISK Recovery Audit", Font = new Font(Font.FontFamily, 23, FontStyle.Bold),
            ForeColor = Color.FromArgb(18, 55, 55), AutoSize = true, Margin = new Padding(0, 0, 0, 12)
        };
        layout.Controls.Add(title, 0, 0);
        layout.SetColumnSpan(title, 3);

        layout.Controls.Add(RowLabel("Project JSON"), 0, 1);
        layout.Controls.Add(project, 1, 1);
        layout.Controls.Add(pickProject, 2, 1);
        layout.Controls.Add(RowLabel("Report folder"), 0, 2);
        layout.Controls.Add(destination, 1, 2);
        layout.Controls.Add(pickOutput, 2, 2);

        var inputs = new FlowLayoutPanel { AutoSize = true, Dock = DockStyle.Fill };
        inputs.Controls.AddRange([example, settings]);
        layout.Controls.Add(inputs, 0, 3);
        layout.SetColumnSpan(inputs, 3);
        var actions = new FlowLayoutPanel { AutoSize = true, Dock = DockStyle.Fill };
        actions.Controls.AddRange([run, cancel, view, openFiles]);
        layout.Controls.Add(actions, 0, 4);
        layout.SetColumnSpan(actions, 3);
        layout.Controls.Add(log, 0, 5);
        layout.SetColumnSpan(log, 3);
        Controls.Add(layout);

        pickProject.Click += (_, _) =>
        {
            using var dialog = new OpenFileDialog
            {
                Title = "Select the audit manifest", Filter = "Audit project (*.json)|*.json", CheckFileExists = true
            };
            if (dialog.ShowDialog(this) == DialogResult.OK) project.Text = dialog.FileName;
        };
        pickOutput.Click += (_, _) =>
        {
            using var dialog = new FolderBrowserDialog { Description = "Choose the report folder" };
            if (dialog.ShowDialog(this) == DialogResult.OK) destination.Text = dialog.SelectedPath;
        };
        example.Click += (_, _) =>
        {
            var sample = Path.Combine(AppContext.BaseDirectory, "examples", "demo", "project.json");
            if (File.Exists(sample)) project.Text = sample;
            else Append("Could not locate the packaged sample.");
        };
        settings.Click += (_, _) =>
        {
            if (File.Exists(project.Text))
            {
                try
                {
                    var start = new ProcessStartInfo("notepad.exe") { UseShellExecute = false };
                    start.ArgumentList.Add(project.Text);
                    using var editor = Process.Start(start);
                }
                catch (System.ComponentModel.Win32Exception ex) { Append(ex.Message); }
            }
            else Append("Choose an existing project JSON file first.");
        };
        run.Click += async (_, _) => await RunAuditAsync();
        cancel.Click += (_, _) => currentRun?.Cancel();
        view.Click += (_, _) => Open(files?.SummaryHtml);
        openFiles.Click += (_, _) => Open(Path.GetDirectoryName(files?.ReportJson));
        AcceptButton = run;
        SetBusy(false);
        Append("Choose a project JSON file or load the sample, then select Run audit.");
    }

    private async Task RunAuditAsync()
    {
        if (string.IsNullOrWhiteSpace(project.Text) || string.IsNullOrWhiteSpace(destination.Text))
        {
            Append("Select the project and report folder.");
            return;
        }

        var projectPath = project.Text.Trim();
        var outputPath = destination.Text.Trim();
        using var cancellation = new CancellationTokenSource();
        currentRun = cancellation;
        files = null;
        SetBusy(true);
        log.Clear();
        var progress = new Progress<string>(Append);
        try
        {
            files = await Task.Run(async () =>
            {
                var audit = new Audit(new AuditInput(projectPath));
                var report = await audit.RunAsync(progress, cancellation.Token);
                return await Reports.WriteAsync(report, outputPath, cancellation.Token);
            }, cancellation.Token);
            Append($"Audit complete. {files.SummaryHtml}");
        }
        catch (OperationCanceledException)
        {
            Append("Audit cancelled.");
        }
        catch (Exception ex)
        {
            Append($"Audit failed: {ex.GetBaseException().Message}");
        }
        finally
        {
            currentRun = null;
            SetBusy(false);
        }
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (currentRun is not null && e.CloseReason == CloseReason.UserClosing)
        {
            currentRun.Cancel();
            e.Cancel = true;
            Append("Cancelling the audit. Close this window when cancellation finishes.");
        }
        base.OnFormClosing(e);
    }

    private void SetBusy(bool busy)
    {
        foreach (var control in new Control[] { run, project, destination, example, settings, pickProject, pickOutput })
            control.Enabled = !busy;
        cancel.Enabled = busy;
        view.Enabled = openFiles.Enabled = !busy && files is not null;
    }

    private void Append(string value)
    {
        if (!IsDisposed) log.AppendText(value + Environment.NewLine);
    }

    private void Open(string? path)
    {
        if (path is null) return;
        try
        {
            using var process = Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        }
        catch (System.ComponentModel.Win32Exception ex) { Append(ex.Message); }
    }

    private static Button NewButton(string text) => new() { Text = text, AutoSize = true };
    private static Label RowLabel(string text) =>
        new() { Text = text, AutoSize = true, Anchor = AnchorStyles.Left };
}
