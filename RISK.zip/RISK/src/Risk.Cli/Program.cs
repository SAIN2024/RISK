using Risk.Core;

if (args.Length == 1 && args[0] is "-h" or "--help")
{
    Usage();
    return 0;
}

var verification = args.Length is 1 or 2 && args[0] == "verify";
var audit = args.Length == 3 && args[0] == "audit";
var checkInputs = args.Length == 2 && args[0] == "check";
if (!verification && !audit && !checkInputs)
{
    Usage();
    return 2;
}

var project = verification ? Path.Combine(AppContext.BaseDirectory, "examples", "demo", "project.json") : args[1];
var destination = verification
    ? args.Length == 2 ? args[1] : Path.Combine(Path.GetTempPath(), "RISK Verification")
    : audit ? args[2] : null;
using var cancellation = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;
    cancellation.Cancel();
};

try
{
    var input = new AuditInput(project);
    if (checkInputs)
    {
        Console.WriteLine($"Valid project with {input.Project.Procedures.Length} procedures, " +
            $"{input.Project.Candidates.Length} candidate pairs, and {input.Evidence.Length} recordings.");
        var unresolved = input.Project.Procedures.Where(p => !input.HasGrounding(p)).ToArray();
        if (unresolved.Length > 0)
            Console.WriteLine("Procedures outside grounded trials: " + string.Join(", ", unresolved.Select(p => p.Id)));
        return 0;
    }
    var report = await new Audit(input).RunAsync(new ConsoleProgress(), cancellation.Token);
    if (verification) Verify(report);
    var files = await Reports.WriteAsync(report, destination!, cancellation.Token);
    foreach (var path in new[] { files.ReportJson, files.SummaryHtml, files.TraceCsv })
        if (!File.Exists(path) || new FileInfo(path).Length == 0)
            throw new IOException("An audit report was not written.");
    Console.WriteLine(files.ReportJson);
    Console.WriteLine(files.SummaryHtml);
    if (verification) Console.Error.WriteLine("PASS: the packaged recovery audit matched all expected results.");
    return 0;
}
catch (OperationCanceledException)
{
    Console.Error.WriteLine("Audit cancelled.");
    return 130;
}
catch (Exception ex)
{
    Console.Error.WriteLine($"Audit failed: {ex.GetBaseException().Message}");
    return 1;
}

static void Verify(AuditReport report)
{
    const string candidate = "buffer-scan/observed-2/observed-6";
    var witnesses = report.Boundaries.Single(b => b.Id == candidate);
    Check(report.Boundaries.Count(b => b.Status == "Confirmed") == 1 &&
        witnesses is { Status: "Confirmed", SafeCoordinate: 2, FailedCoordinate: 6, FailureWitnessAlreadyHazardous: false } &&
        witnesses.SafeTrial.Outcome == "Recovered" && witnesses.FailedTrial.Outcome == "Failed",
        "Paired recovery trials");
    Check(report.Coverage.Any(c => c.Status == "Recovery coverage gap"), "Missing recovery coverage");
    Check(report.Diagnoses.Single().Status == "Supported in counterfactual", "Single-factor counterfactual");
    Check(report.RecordedEvidence.Single().Status == "Recorded witness followed by hazard after cessation",
        "Baseline recording");
    var modified = report.Mitigations.Single();
    var modifiedWitnesses = modified.ReauditedBoundaries.Single(b => b.Id == candidate);
    Check(modifiedWitnesses.SafeTrial.Outcome == "Recovered" && modifiedWitnesses.FailedTrial.Outcome == "Recovered",
        "Mitigation recovery trials");
    Check(modified.Nominal.Single().Comparison == "Preserved", "Nominal regression test");
    Check(modified.RecordedEvidence.Single().Status == "Recovered after observed entry", "Mitigation recording");
    Check(report.InputSha256.Count == 6, "Input manifest and provenance");
}

static void Check(bool passed, string name)
{
    if (!passed) throw new InvalidDataException($"Verification check failed: {name}.");
}

static void Usage()
{
    Console.Error.WriteLine("Usage: Risk.Cli audit <project.json> <report-folder>");
    Console.Error.WriteLine("       Risk.Cli verify [report-folder]");
    Console.Error.WriteLine("       Risk.Cli check <project.json>");
}

sealed class ConsoleProgress : IProgress<string>
{
    public void Report(string value) => Console.Error.WriteLine(value);
}
