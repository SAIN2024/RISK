using System.Text.Json.Nodes;
using Risk.Core;

namespace Risk.Regression;

internal sealed class ExampleWorkspace : IDisposable
{
    private readonly string directory = Directory.CreateTempSubdirectory("risk-regression-").FullName;

    internal ExampleWorkspace()
    {
        var sample = Path.Combine(AppContext.BaseDirectory, "examples", "demo");
        foreach (var path in Directory.GetFiles(sample)) File.Copy(path, PathFor(Path.GetFileName(path)));
    }

    internal string Project => PathFor("project.json");
    internal string Output => PathFor("reports");
    internal string PathFor(string file) => Path.Combine(directory, file);

    internal void Edit(string file, Action<JsonNode> edit)
    {
        var path = PathFor(file);
        var data = JsonNode.Parse(File.ReadAllText(path)) ?? throw new InvalidDataException(file);
        edit(data);
        File.WriteAllText(path, data.ToJsonString());
    }

    internal Task<AuditReport> Audit() => new Audit(new AuditInput(Project)).RunAsync();

    internal static void Assert(bool condition, string failure)
    {
        if (!condition) throw new InvalidOperationException(failure);
    }

    public void Dispose() => Directory.Delete(directory, recursive: true);
}
