using System.Text.Json.Nodes;
using Risk.Core;
using static Risk.Regression.ExampleWorkspace;

namespace Risk.Regression;

internal static class InputTests
{
    internal static void RejectsDuplicateProperty()
    {
        using var example = new ExampleWorkspace();
        var manifest = File.ReadAllText(example.Project);
        var openingBrace = manifest.IndexOf('{');
        File.WriteAllText(example.Project, manifest.Insert(openingBrace + 1, "\"model\":\"model.json\","));
        ExpectInputError(example.Project, "Invalid JSON in 'project.json'");
    }

    internal static void RejectsParentPath()
    {
        using var example = new ExampleWorkspace();
        example.Edit("project.json", json => json["model"] = "../model.json");
        ExpectInputError(example.Project, "leaves the project directory");
    }

    internal static void RejectsInvalidLlmEndpoint()
    {
        using var example = new ExampleWorkspace();
        example.Edit("project.json", json =>
            json["llm"] = JsonNode.Parse("""{"mode":"chatCompletions","endpoint":"file:///model","model":"local","timeoutSeconds":10}"""));
        ExpectInputError(example.Project, "Use an HTTPS or loopback HTTP LLM endpoint");
    }

    private static void ExpectInputError(string project, string message)
    {
        try
        {
            _ = new AuditInput(project);
        }
        catch (AuditInputException ex)
        {
            Assert(ex.Message.Contains(message, StringComparison.Ordinal), ex.Message);
            return;
        }
        throw new InvalidOperationException("Invalid input was accepted.");
    }
}
