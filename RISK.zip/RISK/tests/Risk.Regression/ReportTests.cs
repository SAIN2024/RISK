using System.Globalization;
using System.Text.Json;
using Risk.Core;
using static Risk.Regression.ExampleWorkspace;

namespace Risk.Regression;

internal static class ReportTests
{
    internal static async Task WritesOutputsAndEscapesLabels()
    {
        using var example = new ExampleWorkspace();
        example.Edit("project.json", json => json["nominalCases"]![0]!["id"] = "=example,\"quoted\"");
        example.Edit("model.json", json => json["stepSeconds"] = 0.5);
        var report = await example.Audit();
        var original = CultureInfo.CurrentCulture;
        AuditFiles files;
        try
        {
            CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR");
            files = await Reports.WriteAsync(report, example.Output);
        }
        finally
        {
            CultureInfo.CurrentCulture = original;
        }

        var csv = await File.ReadAllTextAsync(files.TraceCsv);
        var html = await File.ReadAllTextAsync(files.SummaryHtml);
        using var json = JsonDocument.Parse(await File.ReadAllTextAsync(files.ReportJson));
        Assert(csv.Contains("\"'=example,\"\"quoted\"\"\"", StringComparison.Ordinal), "CSV label escaping was not applied.");
        Assert(csv.Contains(",0.5,", StringComparison.Ordinal), "CSV numbers used a locale-dependent decimal format.");
        Assert(html.Contains("href=\"trajectories.csv\"", StringComparison.Ordinal), "The HTML report is missing the CSV link.");
        Assert(json.RootElement.GetProperty("artifactVersion").GetString() == report.ArtifactVersion, "JSON release version missing.");
    }

    internal static async Task CancellationLeavesNoPartialReport()
    {
        using var example = new ExampleWorkspace();
        var report = await example.Audit();
        try
        {
            await Reports.WriteAsync(report, example.Output, new CancellationToken(canceled: true));
        }
        catch (OperationCanceledException)
        {
            Assert(!Directory.EnumerateFileSystemEntries(example.Output).Any(), "A partial output survived cancellation.");
            return;
        }
        throw new InvalidOperationException("Output ignored cancellation.");
    }

    internal static async Task ConcurrentRunsHaveSeparateFolders()
    {
        using var example = new ExampleWorkspace();
        var report = await example.Audit();
        var results = await Task.WhenAll(Reports.WriteAsync(report, example.Output), Reports.WriteAsync(report, example.Output));
        Assert(results[0].ReportJson != results[1].ReportJson, "Concurrent calls used the same report path.");
        Assert(results.All(f => File.Exists(f.SummaryHtml) && File.Exists(f.TraceCsv) && File.Exists(f.ReportJson)),
            "Concurrent calls did not publish complete reports.");
    }
}
