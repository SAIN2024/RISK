using System.Text.Json.Nodes;
using static Risk.Regression.ExampleWorkspace;

namespace Risk.Regression;

internal static class AuditTests
{
    internal static async Task MissingGroundingSkipsTrials()
    {
        using var example = new ExampleWorkspace();
        example.Edit("project.json", json => json["procedures"]![0]!["sources"]![0]!["quote"] = "absent quote");
        var report = await example.Audit();
        Assert(report.Coverage[0].Status == "Unresolved source references", "Missing source was not reported.");
        Assert(report.Boundaries.Length == 0, "Ungrounded procedures entered the audit.");
    }

    internal static async Task HorizonDoesNotImplyFailure()
    {
        using var example = new ExampleWorkspace();
        example.Edit("project.json", json => json["procedures"]![0]!["horizonSteps"] = 1);
        var report = await example.Audit();
        Assert(report.Boundaries.All(b => b.Status == "Unresolved"), "Unresolved trials were classified as failures.");
    }

    internal static async Task EarlyTriggerLeavesForcedBoundaryIntact()
    {
        using var example = new ExampleWorkspace();
        example.Edit("project.json", json =>
        {
            var variant = json["variants"]![0]!;
            variant["model"] = "model.json";
            variant["triggerOverrides"] =
                JsonNode.Parse("""{"queue-drain":[{"variable":"backlog","op":"ge","value":1}]}""");
        });
        var result = (await example.Audit()).Mitigations.Single();
        Assert(result.ReauditedBoundaries.Count(b => b.Status == "Confirmed") == 1, "Forced recovery used the ordinary trigger.");
        Assert(result.Nominal.Single().Comparison == "Compatibility unresolved", "The early trigger was not evaluated.");
    }

    internal static async Task RecordingRequiresProtectionAttestation()
    {
        using var example = new ExampleWorkspace();
        example.Edit("recordings.json", json => json[0]!["protectionsEnabled"] = false);
        var evidence = (await example.Audit()).RecordedEvidence.Single();
        Assert(evidence.Status == "Protections not attested", "The review treated the recording as attested.");
    }
}
