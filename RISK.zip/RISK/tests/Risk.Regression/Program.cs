using Risk.Regression;

(string Name, Func<Task> Execute)[] tests =
[
    ("duplicate JSON property", () => Run(InputTests.RejectsDuplicateProperty)),
    ("relative input path", () => Run(InputTests.RejectsParentPath)),
    ("invalid model endpoint", () => Run(InputTests.RejectsInvalidLlmEndpoint)),
    ("source grounding", AuditTests.MissingGroundingSkipsTrials),
    ("observation horizon", AuditTests.HorizonDoesNotImplyFailure),
    ("early intervention", AuditTests.EarlyTriggerLeavesForcedBoundaryIntact),
    ("evidence attestation", AuditTests.RecordingRequiresProtectionAttestation),
    ("report outputs and CSV labels", ReportTests.WritesOutputsAndEscapesLabels),
    ("cancelled output", ReportTests.CancellationLeavesNoPartialReport),
    ("concurrent report writes", ReportTests.ConcurrentRunsHaveSeparateFolders)
];
var failed = 0;
foreach (var test in tests)
{
    try
    {
        await test.Execute();
        Console.WriteLine($"PASS {test.Name}");
    }
    catch (Exception ex)
    {
        failed++;
        Console.Error.WriteLine($"FAIL {test.Name}: {ex.Message}");
    }
}
return failed == 0 ? 0 : 1;

static Task Run(Action action)
{
    action();
    return Task.CompletedTask;
}
